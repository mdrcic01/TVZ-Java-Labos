package hr.java.production.model;

import hr.java.production.enumeration.Gradovi;
import hr.java.production.exception.WrongCity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.util.Objects;

/**
 * class that holds data of Addresses with builder implemented
 */
public class Address implements Serializable {
    private final String grad;
    private final Long id;
    private final String houseNumber; //optional
    private final String street; //optional
    private final String postalCode; //optional
    //private final String city; //required
    private static final Logger logger = LoggerFactory.getLogger(Address.class);

    /**
     * constructor for Address class
     * @param builderPattern pointer to another class that will build the object
     */
    private Address(AddressBuilder builderPattern){
        this.grad = builderPattern.grad;
        this.id = builderPattern.id;
        //this.city = builderPattern.city;
        this.houseNumber = builderPattern.houseNumber;
        this.postalCode = builderPattern.postalCode;
        this.street = builderPattern.street;
        logger.info("Kreiran je objekt tipa Address!", Address.class.getSimpleName());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Address address = (Address) o;
        return grad == address.grad && Objects.equals(houseNumber, address.houseNumber) && Objects.equals(street, address.street);
    }

    @Override
    public int hashCode() {
        return Objects.hash(grad, houseNumber, street);
    }

    public String getHouseNumber() {
        return houseNumber;
    }

    public String getStreet() {
        return street;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public Long getID(){
        return id;
    }

    public String getGrad() {
        return grad;
    }

    /**
     * method that converts ind displays data for the Address
     * @return String value formatted from all data together
     */
    @Override
    public String toString() {
        return "User: "+this.street+", "+this.houseNumber+", "+this.grad;
    }

    /**
     * static BuilderClass that constructs and filters required and optional data for an Address
     */
    public static class AddressBuilder {
        private String grad;
        private Long id;
        //private final String city;
        private String street;
        private String houseNumber;
        private String postalCode;

        /**
         * constructor for required fields
         */
        public AddressBuilder(){
        }

        public AddressBuilder id(Long id){
            this.id = id;
            return this;
        }

        public AddressBuilder city(String city) {
            this.grad = city;
            return this;
        }
        public AddressBuilder postalCode(String postalCode) {
            this.postalCode = postalCode;
            return this;
        }
        /**
         * constructor for optional fields
         * @param street one of the optional fields in Address class
         * @return street variable to add in an Address instance
         */
        public AddressBuilder street(String street){
            this.street = street;
            return this;
        }

        /**
         * constructor for optional fields
         * @param houseNumber one of the optional fields in Address class
         * @return houseNumber variable to add in an Address instance
         */
        public AddressBuilder houseNumber(String houseNumber){
            this.houseNumber = houseNumber;
            return this;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            AddressBuilder that = (AddressBuilder) o;
            return grad == that.grad && Objects.equals(street, that.street) && Objects.equals(houseNumber, that.houseNumber);
        }

        @Override
        public int hashCode() {
            return Objects.hash(grad, street, houseNumber);
        }


        /**
         * builder method that will create and initialize Address instance
         * @return created instance
         */
        public Address build(){
            Address address = new Address(this);
            return address;
        }
    }
}
