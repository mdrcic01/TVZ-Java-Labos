package hr.java.production.model;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Objects;

/**
 * non sealed class Laptop that implements Technical sealed interface
 */
public non-sealed class Laptop extends Item implements Technical, Serializable {
    private static final Logger logger = LoggerFactory.getLogger(Laptop.class);
    int warranty;

    /**
     * constructs an instance of Laptop class
     * @param name sets name variable
     * @param category sets category variable
     * @param width sets width variable
     * @param height sets height variable
     * @param length sets length variable
     * @param productionCost sets productionCost variable
     * @param sellingPrice sets sellingPrice variable
     * @param discount sets discount variable
     * @param warranty sets warranty variable
     */
    public Laptop(String name, Category category, BigDecimal width, BigDecimal height, BigDecimal length,
                  BigDecimal productionCost, BigDecimal sellingPrice, Discount discount, int warranty, Long id) {
        super(name, category, width, height, length, productionCost, sellingPrice, discount, id);
        this.warranty = warranty;
        logger.info("Stvoren je (non-sealed)objekt tipa Laptop!", Laptop.class.getSimpleName());
    }

    public int getWarranty() {
        return warranty;
    }

    public void setWarranty(int warranty) {
        this.warranty = warranty;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Laptop laptop = (Laptop) o;
        return warranty == laptop.warranty;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), warranty);
    }

    /**
     * overridden method from sealed interface Technical
     * @return value of warranty in months
     */
    @Override
    public int warrantyDuration() {
        return warranty;
    }
}
