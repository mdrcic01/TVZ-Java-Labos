package hr.java.production.main;

import hr.java.production.exception.FactoryAndStoreException;
import hr.java.production.exception.SameCategoryException;
import hr.java.production.exception.WrongCity;
import hr.java.production.genericsi.FoodStore;
import hr.java.production.genericsi.TechnicalStore;
import hr.java.production.model.*;
import hr.java.production.sort.ProductionSorter;
import hr.java.production.sort.VolumeSorter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.math.BigDecimal;
import java.math.MathContext;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

/**
 * main class that runs the program and calls other methods
 */
public class Main {


    private static final int NO_OF_CATEGORIES = 2;
    private static final int NO_OF_ITEMS = 3;
    private static final int NO_OF_FACTORIES = 2;
    private static final int NO_OF_FACTORY_ITEMS = 2;
    private static final int NO_OF_STORES = 2;
    private static final int NO_OF_STORE_ITEMS = 2;
    private static final String STORES_PATH = "dat/stores.txt";
    private static final String FACTORIES_PATH = "dat/factories.txt";
    private static final String ITEMS_PATH = "dat/items.txt";
    private static final String ADDRESSES_PATH = "dat/addresses.txt";
    private static final String FACTORY_SERIALIZATION_PATH = "dat/factorySerialization.dat";
    private static final String STORE_SERIALIZATION_PATH = "dat/storeSerialization.dat";
    private static final int NO_OF_LINES_FOR_CATEGORIES = 3;
    private static final String CATEGORIES_PATH = "dat/categories.txt";
    private static final int NO_OF_LINES_FOR_ITEMS = 11;
    private static final int NO_OF_LINES_FOR_STORES = 4;
    private static final int NO_OF_LINES_FOR_ADDRESSES = 3;
    private static final int NO_OF_LINES_FOR_FACTORIES = 4;
    private static final Logger logger = LoggerFactory.getLogger(Main.class);
    public static void main(String[] args) {
        Scanner userInput = new Scanner(System.in);
        logger.info("Pocetak rada programa!", Main.class.getSimpleName());

        List<Category> categoryArray= new ArrayList<>();
        //categoryInput(userInput, categoryArray);
        categoryRead(categoryArray);
        printCategories(categoryArray);

        List<Item> itemArray = new ArrayList<>();
        //itemInput(userInput, itemArray, categoryArray);
        itemRead(itemArray, categoryArray);
        itemDisplay(itemArray);

        itemArray.sort(new VolumeSorter());

        System.out.println("NAKON SORTIRANJA!");
        itemDisplay(itemArray);

        List<Address> addressList = new ArrayList<>();
        addressRead(addressList);

        optionalFilterForItemsWithDiscount(itemArray);

        averagePriceOfAboveAverageItems(itemArray);

        highestAndLowestPriceFilter(itemArray);

        System.out.println("Najvise kalorija ima: " + mostCalories(itemArray).getName());
        System.out.println("Najvecu cijenu s obzirom na masu ima: " + highestPrice(itemArray).getName());
        System.out.print("Laptop s najkracim garatnim rokom je: ");
        displayOneItem(shortestWarrantyLaptop(itemArray));

        List<Store> storeArray = new ArrayList<>();
        //storeInput(userInput, storeArray, itemArray);
        storeRead(storeArray, itemArray);

        System.out.println("Broj artikala u svakoj trgovini: ");
        storeArray.stream().map(it -> it.getItems().size()).forEach(System.out::println);

        storesWithAverageNumberOfItems(storeArray);

        streamSorterTiming(storeArray);

        bubbleSortTiming(storeArray);

        for(Store store : storeArray){
            System.out.println("STORE: " + store.getName());
            itemDisplay(store.getItems().stream().toList());
        }

        Set<Item> storeItems = new HashSet<>();
        storeItems.add(itemArray.get(0));
        storeItems.add(itemArray.get(1));
        FoodStore lidl = new FoodStore("Lidl", "www.lidl.hr", storeItems,
                new Random().longs(1, (100 + 1)).limit(1).findFirst().getAsLong());
        TechnicalStore vacom = new TechnicalStore("Vacom", "www.vacom.hr", storeItems,
                new Random().longs(1, (100 + 1)).limit(1).findFirst().getAsLong());

        System.out.println("LIDL itemDisplay");
        itemDisplay(lidl.getItemList());
        System.out.println("VACOM itemDisplay");
        itemDisplay(vacom.getItemList());

        List<Factory> factoryArray = new ArrayList<>();
        //factoryInput(userInput, factoryArray, itemArray);
        factoriesRead(factoryArray, itemArray, addressList);


        for(int i=0; i<factoryArray.size(); i++){
            itemDisplay(factoryArray.get(i).getItems().stream().toList());
        }

        System.out.println("Najjeftiniji proizvod ima: " + cheapestProduct(storeArray).getName());
        System.out.println("Najveci proizvod ima: " + biggestProduct(factoryArray).getName());

        List<Factory> factory = factoryArray.stream()
                .filter(it -> it.getItems().size() > 4)
                .collect(Collectors.toList());
        try{
            ObjectOutputStream out = new ObjectOutputStream(
                    new FileOutputStream(FACTORY_SERIALIZATION_PATH));
            out.writeObject(factory);
            out.close();
        }
        catch (IOException ex){
            System.out.println("First - error has occurred" + ex);
        }

        List<Store> store = storeArray.stream()
                .filter(it -> it.getItems().size() > 4)
                .collect(Collectors.toList());
        try{
            ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(STORE_SERIALIZATION_PATH));
            out.writeObject(store);
            out.close();
        }
        catch(IOException ex){
            System.out.println("Second - error has occurred" + ex);
        }



        try{
            ObjectInputStream in = new ObjectInputStream(new FileInputStream(FACTORY_SERIALIZATION_PATH));
            List<Factory> deserializedFactoryList = (List<Factory>) in.readObject();
            in.close();

            System.out.println("Deserijalizirane tvornice:");
            deserializedFactoryList.forEach(System.out::println);

        }
        catch (IOException | ClassNotFoundException ex){
            System.out.println("Third - error has occurred" + ex);
            ex.printStackTrace();
        }


        try{
            ObjectInputStream in = new ObjectInputStream(new FileInputStream(STORE_SERIALIZATION_PATH));
            List<Store> deserializedStoreList = (List<Store>) in.readObject();
            in.close();

            System.out.println("Deserializirane trgovine: ");
            deserializedStoreList.forEach(System.out::println);
        }
        catch (IOException | ClassNotFoundException ex){
            System.out.println("Fourth - error has occurred" + ex);
            ex.printStackTrace();
        }

        System.out.println("KRAJ!");
    }

    /**
     * prints average price of items with above average volume
     * @param itemArray array of selected items
     */
    private static void averagePriceOfAboveAverageItems(List<Item> itemArray){
        BigDecimal averageSum = itemArray.stream().map(item -> item.volumeCalc())
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .round(new MathContext(4));
        long itemCount = itemArray.stream().count();
        BigDecimal averageValue = averageSum.divide(BigDecimal.valueOf(itemCount), new MathContext(4));

        BigDecimal averageSellingPriceSum = itemArray.stream()
                .filter(it -> it.volumeCalc().compareTo(averageValue) > 0)
                .map(it -> it.getSellingPrice())
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        itemCount = itemArray.stream()
                .filter(it -> it.volumeCalc().compareTo(averageValue) > 0)
                .count();

        BigDecimal averageSellingPrice = averageSellingPriceSum.divide(BigDecimal.valueOf(itemCount));

        System.out.println("Prosjecna cijena natprosjecno velikih predmeta je: " + averageSellingPrice);
    }

    /**
     * prints items with discount (with optional)
     * @param itemArray array of selected items
     */
    private static void optionalFilterForItemsWithDiscount(List<Item> itemArray){
        Optional<List<Item>> optList = itemArray.stream()
                .filter(it -> it.getDiscount().discountAmount().compareTo(BigDecimal.valueOf(0))>0)
                .collect(Collectors.collectingAndThen(Collectors.toList(),
                        item -> !item.isEmpty() ? Optional.of(item) : Optional.empty()));

        System.out.println("PREDMETI S POPUSTOM");
        for(Item item : optList.get()){
            System.out.println(item.getName());
        }
    }

    /**
     * prints items with highest and lowest price
     * @param itemArray array of selected items
     */
    private static void highestAndLowestPriceFilter(List<Item> itemArray){
        Map<Category, List<Item>> newMap = new HashMap<>();
        for(int i=0; i < itemArray.size(); i++){
            if(newMap.containsKey(itemArray.get(i).getCategory())){
                newMap.get(itemArray.get(i).getCategory()).add(itemArray.get(i));
            }
            else{
                newMap.put(itemArray.get(i).getCategory(), new ArrayList<>());
                newMap.get(itemArray.get(i).getCategory()).add(itemArray.get(i));
            }
        }

        for(Category key : newMap.keySet()){
            newMap.get(key).stream().sorted(new ProductionSorter());
        }

        for(Category key : newMap.keySet()){
            System.out.println(key.getName() + "=");
            itemDisplay(newMap.get(key));
        }

        for(Category key : newMap.keySet()){
            System.out.println("U KATEGORIJI " + key.getName());
            System.out.println("Najmanju cijenu ima: " + newMap.get(key).get(0).getName() + " - " +
                    newMap.get(key).get(0).getSellingPrice());
            System.out.println("Najvecu cijenu ima: " + newMap.get(key).get(newMap.get(key).size()-1).getName() + " - " +
                    newMap.get(key).get(newMap.get(key).size()-1).getSellingPrice());
        }
    }

    /**
     * lists stores with average number of items
     * @param storeArray list of stores
     */
    private static void storesWithAverageNumberOfItems(List<Store> storeArray){
        int noOfItems = 0;
        for(Store store: storeArray){
            noOfItems += store.getItems().size();
        }
        BigDecimal averageNoOfItems = BigDecimal.valueOf(noOfItems)
                .divide(BigDecimal.valueOf(storeArray.size()), new MathContext(4));

        List<Store> storesWithAverageNoOfItems = storeArray.stream()
                .filter(it -> it.getItems().size() == averageNoOfItems.longValue())
                .collect(Collectors.toList());

        System.out.println("Trgovine s prosjecnim brojem artikala: ");
        int index = 1;
        for(Store store : storesWithAverageNoOfItems){
            System.out.println(index + ") " + store.getName());
            index++;
        }
    }

    /**
     * sorts with stream and prints sorted list
     * @param storeArray list of stores
     */
    private static void streamSorterTiming(List<Store> storeArray){
        for(Store store : storeArray){
            Instant start = Instant.now();

            List<Item> items = store.getItems().stream().toList();
            items.stream().sorted(new VolumeSorter());

            Instant end = Instant.now();

            System.out.println("Vrijeme s lambda funkcijom!");

            Duration between = Duration.between(start, end);
            System.out.println( between ); // PT1.001S
            System.out.format("%dD, %02d:%02d:%02d.%04d \n", between.toDays(),
                    between.toHours(), between.toMinutes(), between.getSeconds(), between.toMillis());
        }
    }

    /**
     * sorts with bubbleSort and prints the list
     * @param storeArray list of stores
     */
    private static void bubbleSortTiming(List<Store> storeArray){
        for(Store store : storeArray){
            Instant start = Instant.now();

            //List<Item> iArray = store.getItems().stream().toList();
            List<Item> iArray = new ArrayList<>(store.getItems().stream().toList());
            //Item tmp = null;
            Optional<Item> tmp = Optional.empty();
            for(int j=0; j< iArray.size(); j++){
                for(int i = 0; i<iArray.size()-1; i++){
                    if(iArray.get(i).volumeCalc().compareTo(iArray.get(i+1).volumeCalc())>0){
                        tmp = Optional.ofNullable(iArray.get(i));
                        iArray.set(i, iArray.get(i+1));
                        iArray.set((i+1), tmp.get());
                    }
                }
            }

            Instant end = Instant.now();
            System.out.println("Vrijeme bez lambde!");
            Duration between = Duration.between(start, end);
            System.out.println( between ); // PT1.001S
            System.out.format("%dD, %02d:%02d:%02d.%04d \n", between.toDays(),
                    between.toHours(), between.toMinutes(), between.getSeconds(), between.toMillis());
        }
    }

    /**
     * lists item received through parameters
     * @param item displayed item
     */
    private static void displayOneItem(Item item){
        logger.info("Ispis pojedinog artikla.", Main.class.getSimpleName());
        System.out.println(item.getName()+ " - " + item.getSellingPrice());
    }

    /**
     * searches for an article with the most calories
     * @param itemArray array with available articles
     * @return selected item
     */
    private static Item mostCalories(List<Item> itemArray){
        logger.info("Racunanje artikla s najvise kalorija.", Main.class.getSimpleName());
        int best = 1;
        int index = 0;
        for(int i=0; i<itemArray.size(); i++){
            if(itemArray.get(i) instanceof CottageCheese || itemArray.get(i) instanceof Lasagna){
                if(((Edible) itemArray.get(i)).calculateKiloCalories() > best){
                    best = ((Edible) itemArray.get(i)).calculateKiloCalories();
                    index = i;
                }
            }
        }
        return itemArray.get(index);
    }

    /**
     * searches for an article with the highest price
     * @param itemArray array with available articles
     * @return selected item
     */
    private static Item highestPrice(List<Item> itemArray){
        logger.info("Racunanje artikla s najvisom cijenom.", Main.class.getSimpleName());
        BigDecimal best = BigDecimal.valueOf(0);
        int index = 0;
        for(int i=0; i< itemArray.size(); i++){
            if(itemArray.get(i) instanceof CottageCheese || itemArray.get(i) instanceof Lasagna){
                BigDecimal value = ((Edible) itemArray.get(i)).calculatePrice();
                if(value.compareTo(best)>0){
                    best = value;
                    index = i;
                }
            }
        }
        return itemArray.get(index);
    }

    /**
     * displays all available categories
     * @param categoryArray list of all available categories
     */
    private static void printCategories(List<Category> categoryArray) {
        logger.info("Izlist kategorija!", Main.class.getSimpleName());
        System.out.println("Ispis kategorija!");
        for(int i=0; i<NO_OF_CATEGORIES; i++){
            System.out.println((i+1) + ") " + categoryArray.get(i).getName() + " - " +
                    categoryArray.get(i).getDescription());
        }
    }

    public static void categoryRead(List<Category> categoryArray) {
        try(BufferedReader categoryFileReader = new BufferedReader(new FileReader(CATEGORIES_PATH))){
            String line;
            Integer lineCounter = 1;
            String tmpName = " ";
            Long tmpID = Long.valueOf(0);
            String tmpDesc = " ";
            while((line = categoryFileReader.readLine()) != null){

                switch(lineCounter%NO_OF_LINES_FOR_CATEGORIES){
                    case 1 -> {
                        tmpID = Long.parseLong(line);
                    }
                    case 2 -> {
                        tmpName = line;
                    }
                    case 0 -> {
                        tmpDesc = line;
                        categoryArray.add(new Category(tmpName, tmpDesc, tmpID));
                    }
                }

                lineCounter++;
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    /**
     * input of required categories
     * @param userInput Scanner that stores user's input
     * @param categoryArray array where categories are stored
     */
    public static void categoryInput(Scanner userInput, List<Category> categoryArray) {
        logger.info("Unos kategorija...", Main.class.getSimpleName());
        System.out.println("Unos kategorija: ");
        boolean permit = false;

        for(int i=0; i<NO_OF_CATEGORIES; i++){
            //String tmpName = null;
            Optional<String> tmpName = Optional.empty();
            do {
                try{
                    permit = true;
                    System.out.print("Naziv " + (i+1) + ". kategorije: ");
                    //tmpName = userInput.nextLine();
                    tmpName = Optional.ofNullable(userInput.nextLine());
                    for(int j=0; j < i; j++){
                        if(Objects.equals(categoryArray.get(j).getName(), tmpName)){
                            permit = false;
                            throw new SameCategoryException("Kategorija vec postoji! Unesite ponovno!");
                        }
                    }
                }
                catch(SameCategoryException ex){
                    System.out.println(ex.getMessage());
                    logger.error("Greska! Unjeta kategorija vec postoji!", ex);
                }

            }while(permit == false);
            System.out.print("Opis " + (i+1) + ". kategorije: ");
            String tmpDesc = userInput.nextLine();
            System.out.print("ID kategorije: " );
            Long tmpID = userInput.nextLong();
            userInput.nextLine();

            Category tmpCat = new Category(tmpName.get(), tmpDesc, tmpID);
            //categoryArray.set(i, new Category(tmpName, tmpDesc));
            categoryArray.add(tmpCat);
        }
        logger.info("...zavrsen unos kategorija.", Main.class.getSimpleName());
    }

    public static void itemRead(List<Item> itemArray, List<Category> categoryArray){

        try(BufferedReader itemFileReader = new BufferedReader((new FileReader(ITEMS_PATH) ))){

            String line;
            Integer lineCounter = 1;

            Long tmpID = Long.valueOf(0);
            String className = " ";
            Category tmpCategory = null;
            String tmpName = "";
            BigDecimal tmpWidth = BigDecimal.valueOf(0), tmpHieght = BigDecimal.valueOf(0),
                    tmpLength = BigDecimal.valueOf(0), tmpProductionCost = BigDecimal.valueOf(0),
                    tmpSellingPrice = BigDecimal.valueOf(0);
            Discount discount = null;
            BigDecimal tmpWeight;
            int tmpWarranty = 0;


            while((line = itemFileReader.readLine()) != null){
                switch(lineCounter%NO_OF_LINES_FOR_ITEMS){
                   case 1 -> {
                       tmpID = Long.parseLong(line);
                   }
                   case 2 -> {
                       className = line;
                   }
                   case 3 -> {
                       tmpName = line;
                   }
                   case 4 -> {
                       for(int i=0; i< categoryArray.size(); i++){
                           if(line.equals(categoryArray.get(i).getName())){

                               tmpCategory = categoryArray.get(i);

                           }
                       }
                   }
                   case 5 -> {
                       tmpWidth = BigDecimal.valueOf(Long.parseLong(line));
                   }
                   case 6 -> {
                       tmpHieght = BigDecimal.valueOf(Long.parseLong(line));
                   }
                   case 7 -> {
                       tmpLength = BigDecimal.valueOf(Long.parseLong(line));
                   }
                   case 8 -> {
                       tmpProductionCost = BigDecimal.valueOf(Long.parseLong(line));
                   }
                   case 9 -> {
                       tmpSellingPrice = BigDecimal.valueOf(Long.parseLong(line));
                   }
                   case 10 -> {
                       discount = new Discount(BigDecimal.valueOf(Long.parseLong(line)));
                   }
                   case 0 -> {
                       if(className.compareTo("Lazanje") == 0){
                           tmpWeight = BigDecimal.valueOf(Long.parseLong(line));
                           itemArray.add(new Lasagna(tmpName, tmpCategory, tmpWidth, tmpHieght, tmpLength,
                                   tmpProductionCost, tmpSellingPrice, discount, tmpWeight, tmpID));
                       }
                       else if(className.compareTo("SvjeziSir") == 0 ){
                           tmpWeight = BigDecimal.valueOf(Long.parseLong(line));
                           itemArray.add(new CottageCheese(tmpName, tmpCategory, tmpWidth, tmpHieght, tmpLength,
                                   tmpProductionCost, tmpSellingPrice, discount, tmpWeight, tmpID));
                       }
                       else if(className.compareTo("Laptop") == 0){
                           tmpWarranty = Integer.parseInt(line);
                           itemArray.add(new Laptop(tmpName, tmpCategory, tmpWidth, tmpHieght, tmpLength,
                                   tmpProductionCost, tmpSellingPrice, discount, tmpWarranty, tmpID));
                       }
                   }
                }
                lineCounter++;
            }


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * input method for items/articles
     * @param userInput Scanner that stores user's input
     * @param itemArray pointer on the array where items are stored
     * @param categoryArray pointer on the category array to display available categories
     */
    private static void itemInput(Scanner userInput, List<Item> itemArray, List<Category> categoryArray){
        logger.info("Unos artikala!", Main.class.getSimpleName());
        System.out.println("Unos predmeta: ");
        for(int i=0; i<NO_OF_ITEMS; i++){

            boolean permit = false;
            int selection = 0;
            do{
                try{
                    permit = true;
                    System.out.println("Unosite li:\n1) jestivo\n2) nejestivo");
                    selection = userInput.nextInt();
                    //userInput.nextLine();
                }
                catch (InputMismatchException ex){
                    System.out.println("Nevaljani unos! Pokusajte ponovno!");
                    logger.error("Greska pri unosu!", ex);
                    permit=false;
                    userInput.nextLine();
                }
                if((selection < 1 || selection > 2) && permit == true){
                    System.out.println("Nevaljani unos! Pokusajte ponovno!");
                    logger.error("Unos izlazi iz zadanih granica!", Main.class.getSimpleName());
                    permit=false;
                }
            }while(permit==false);

            int newSelection = 0;
            //String tmpName = null;
            Optional<String> tmpName = Optional.empty();
            if(selection==1){
                do{
                    try{
                        permit = true;
                        System.out.print("Odabir hrane za unos:\n1) Svjezi Sir\n2) Lazanje\n ");
                        newSelection = userInput.nextInt();
                        //userInput.nextLine();
                    }
                    catch(InputMismatchException ex){
                        System.out.println("Nevaljani unos, pokusajte ponovno!");
                        logger.error("Greska pri unosu!", ex);
                        permit = false;
                        userInput.nextLine();
                    }
                    if((newSelection < 1 || newSelection > 2)&& permit == true){
                        System.out.println("Nevaljani unos, pokusajte ponovno!");
                        logger.error("Unos izlazi iz zadanih granica!", Main.class.getSimpleName());
                        permit = false;
                    }
                }while(permit == false);
            }
            else if(selection == 2){
                do{
                    try{
                        permit = true;
                        System.out.print("Odabir hrane za unos:\n1) Laptop\n ");
                        newSelection = userInput.nextInt();
                        //userInput.nextLine();
                    }
                    catch (InputMismatchException ex){
                        System.out.println("Nevaljani unos, pokusajte ponovno!");
                        logger.error("Greska pri unosu!", ex);
                        permit = false;
                        userInput.nextLine();
                    }
                    if((newSelection != 1)&&permit==true){
                        System.out.println("Nevaljani unos, pokusajte ponovno!");
                        logger.error("Unos izlazi iz zadanih granica!", Main.class.getSimpleName());
                        permit = false;
                    }
                }while(permit == false);
            }
            userInput.nextLine();
            System.out.print("Unesi naziv: ");
            tmpName = Optional.ofNullable(userInput.nextLine());
            Optional<Long> tmpID = Optional.empty();
            System.out.print("ID artikla: ");
            do {
                try{
                    permit = true;
                    tmpID = Optional.of(userInput.nextLong());
                }
                catch (InputMismatchException ex){
                    System.out.println("Nevaljani unos, pokusajte ponovno!");
                    logger.error("Greska pri unosu!", ex);
                    permit = false;
                    userInput.nextLine();
                }

            }while(permit == false);

            System.out.println("Unesi kategoriju: ");
            boolean permission = false;
            int tmpCategory = 0;
            do {
                for (int j = 0; j < NO_OF_CATEGORIES; j++) {

                    System.out.println(j + 1 + ") " + categoryArray.get(j).getName());

                }
                try {
                    permission = true;
                    tmpCategory = userInput.nextInt();
                    //userInput.nextLine();
                } catch (InputMismatchException ex) {
                    System.out.println("Neispravan unos, pokusajte ponovno!");
                    logger.error("Greska pri unosu!", ex);
                    permission = false;
                    userInput.nextLine();
                }
                if ((tmpCategory < 1 || tmpCategory > NO_OF_CATEGORIES) && permission == true) {
                    System.out.println("Neispravan unos, pokusajte ponovno!");
                    logger.error("Unos izlazi iz zadanih granica!", Main.class.getSimpleName());
                    permission = false;
                }
                //userInput.nextLine();
            }while(permission == false);

            BigDecimal tmpWidth = BigDecimal.valueOf(0);
            BigDecimal tmpHeight = BigDecimal.valueOf(0);
            BigDecimal tmpLength = BigDecimal.valueOf(0);
            BigDecimal tmpProductionCost = BigDecimal.valueOf(0);
            BigDecimal tmpSellingPrice = BigDecimal.valueOf(0);
            System.out.println("Unesite dimenzije predmeta: ");
            do {
                try{
                    permit = true;
                    System.out.print("Sirina: ");
                    tmpWidth = userInput.nextBigDecimal();
                    //userInput.nextLine();
                }
                catch (InputMismatchException ex){
                    System.out.println("Nevaljani unos! Pokusajte ponovno!");
                    logger.error("Greska pri unosu!", ex);
                    permit = false;
                    userInput.nextLine();
                }
            }while(permit == false);
            do {
                try{
                    permit = true;
                    System.out.print("Visina: ");
                    tmpHeight = userInput.nextBigDecimal();
                    //userInput.nextLine();
                }
                catch (InputMismatchException ex){
                    System.out.println("Nevaljani unos! Pokusajte ponovno!");
                    logger.error("Greska pri unosu!", ex);
                    permit = false;
                    userInput.nextLine();
                }
            }while(permit == false);
            do {
                try{
                    permit = true;
                    System.out.print("Duljina: ");
                    tmpLength = userInput.nextBigDecimal();
                    //userInput.nextLine();
                }
                catch (InputMismatchException ex){
                    System.out.println("Nevaljani unos! Pokusajte ponovno!");
                    logger.error("Greska pri unosu!", ex);
                    permit = false;
                    userInput.nextLine();
                }
            }while(permit == false);
            do {
                try{
                    permit = true;
                    System.out.print("Unesite cijenu proizvodnje (kn): ");
                    tmpProductionCost = userInput.nextBigDecimal();
                    //userInput.nextLine();
                }
                catch (InputMismatchException ex){
                    System.out.println("Nevaljani unos! Pokusajte ponovno!");
                    logger.error("Greska pri unosu!", ex);
                    permit = false;
                    userInput.nextLine();
                }
            }while(permit == false);
            do {
                try{
                    permit = true;
                    System.out.print("Unesite prodajnu cijenu (kn): ");
                    tmpSellingPrice = userInput.nextBigDecimal();
                    //userInput.nextLine();
                }
                catch (InputMismatchException ex){
                    System.out.println("Nevaljani unos! Pokusajte ponovno!");
                    logger.error("Greska pri unosu!", ex);
                    permit = false;
                    userInput.nextLine();
                }
            }while(permit == false);

            BigDecimal tmpDiscountPercentage = BigDecimal.valueOf(0);
            do {
                try{
                    permit = true;
                    System.out.print("Unesite popust: ");
                    tmpDiscountPercentage = userInput.nextBigDecimal();
                    //userInput.nextLine();
                }
                catch (InputMismatchException ex){
                    System.out.println("Pokusajte ponovno!");
                    logger.error("Greska pri unosu!", ex);
                    permit = false;
                    userInput.nextLine();
                }
                if(tmpDiscountPercentage.compareTo(BigDecimal.valueOf(0)) < 0 ||
                        tmpDiscountPercentage.compareTo(BigDecimal.valueOf(100))>0){
                    System.out.println("Pokusajte ponovno!");
                    logger.error("Unos izlazi iz zadanih granica!", Main.class.getSimpleName());
                    permit = false;
                }
            }while(permit == false);
            Discount tmpDiscount = new Discount(tmpDiscountPercentage);
            BigDecimal tmpWeight = BigDecimal.valueOf(0);
            int tmpWarranty = 0;
            if(selection==1){
                if(newSelection == 1){
                    do {
                        try {
                            permit = true;
                            System.out.print("Unesite masu proizvoda: ");
                            tmpWeight = userInput.nextBigDecimal();
                            //userInput.nextLine();
                        }
                        catch (InputMismatchException ex){
                            System.out.println("Neispravan unos! Pokusajte ponovno!");
                            logger.error("Greska pri unosu!", ex);
                            permit = false;
                            userInput.nextLine();
                        }
                    }while(permit == false);
                    itemArray.add(new CottageCheese(tmpName.get(), categoryArray.get(tmpCategory-1), tmpWidth, tmpHeight,
                            tmpLength, tmpProductionCost, tmpSellingPrice, tmpDiscount, tmpWeight, tmpID.get()));
                }
                else if(newSelection == 2){
                    do {
                        try{
                            permit = true;
                            System.out.print("Unesite masu proizvoda: ");
                            tmpWeight = userInput.nextBigDecimal();
                            //userInput.nextLine();
                        }
                        catch (InputMismatchException ex){
                            System.out.println("Nevaljani unos! Pokusajte ponovno!");
                            logger.error("Greska pri unosu!", ex);
                            permit = false;
                            userInput.nextLine();
                        }
                    }while(permit == false);
                    itemArray.add(new Lasagna(tmpName.get(), categoryArray.get(tmpCategory-1), tmpWidth, tmpHeight,
                            tmpLength, tmpProductionCost, tmpSellingPrice, tmpDiscount, tmpWeight, tmpID.get()));
                }
            }
            else if(selection == 2){
                do {
                    try{
                        permit = true;
                        System.out.print("Unesite trajanje garancije: ");
                        tmpWarranty = userInput.nextInt();
                        userInput.nextLine();
                    }
                    catch (InputMismatchException ex){
                        System.out.println("Nepravilan unos! Pokusajte ponovno!");
                        logger.error("Greska pri unosu!", ex);
                        permit = false;
                        userInput.nextLine();
                    }
                }while(permit == false);
                Laptop tmpLap = new Laptop(tmpName.get(), categoryArray.get(tmpCategory-1), tmpWidth, tmpHeight,tmpLength,
                        tmpProductionCost, tmpSellingPrice, tmpDiscount, tmpWarranty, tmpID.get());
                itemArray.add(tmpLap);
            }

            /*itemArray[i] = new Item(tmpName, categoryArray[tmpCategory], tmpWidth, tmpHeight,tmpLength,
                    tmpProductionCost, tmpSellingPrice, tmpDiscount);*/
        }
        logger.info("Kraj unosa artikala!", Main.class.getSimpleName());
    }

    /**
     * displays list of available items
     * @param itemArray list of items/articles
     */
    private static void itemDisplay(List<Item> itemArray){
        logger.info("Ispis artikala iz predane liste", Main.class.getSimpleName());
        System.out.println("ISPIS ARTIKALA!");
        for(int i=0; i<itemArray.size(); i++){
            System.out.println((i+1) + ") " + itemArray.get(i).getName() + " - " + itemArray.get(i).getSellingPrice());
        }
    }


    private static void factoriesRead(List<Factory> factoryArray, List<Item> itemArray, List<Address> addressList){
        try(BufferedReader factoryInputReader = new BufferedReader(new FileReader(FACTORIES_PATH))){
            String line;
            Integer lineCounter = 1;
            Long tmpID = Long.valueOf(0);
            String tmpName = "";
            Address tmpAddress = null;

            while((line = factoryInputReader.readLine()) != null){
                switch(lineCounter%NO_OF_LINES_FOR_FACTORIES){
                    case 1 -> {
                        tmpID = Long.parseLong(line);
                    }
                    case 2 -> {
                        tmpName = line;
                    }
                    case 3 -> {
                        tmpAddress = addressList.get(Integer.parseInt(line)-1);
                    }
                    case 0 -> {
                        String[] lista = line.split(",");
                        Set<Item> tmpSet = new HashSet<>();
                        for(int i=0; i<lista.length; i++){
                            tmpSet.add(itemArray.get(Integer.parseInt(lista[i])-1));
                        }
                        factoryArray.add(new Factory(tmpName, tmpAddress, tmpSet, tmpID));
                    }
                }
                lineCounter++;
            }


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * input method for Factories
     * @param userInput Scanner that stores user's input
     * @param factoryArray array where factory information will be stored
     * @param itemArray array for items in the factory
     */
    private static void factoryInput(Scanner userInput, List<Factory> factoryArray, List<Item> itemArray){
        logger.info("Unos tvornica!", Main.class.getSimpleName());
        System.out.println("UNOS TVORNICA");
        for(int i=0; i<NO_OF_FACTORIES; i++){
            System.out.print("Naziv " + (i+1) + ". tvornice: ");
            String tmpName = userInput.nextLine();

            System.out.print("ID tvornice: " );
            Long tmpID = userInput.nextLong();
            userInput.nextLine();

            Address tmpAddress;
            tmpAddress = addressInput(userInput);

            Set<Item> factoryItemArray = new HashSet<>();
            //itemInput(userInput, factoryItemArray, categoryArray);
            itemSelection(userInput, itemArray, factoryItemArray);

            factoryArray.add(new Factory(tmpName, tmpAddress, (Set<Item>) factoryItemArray, tmpID));
        }
    }


    private static void addressRead(List<Address> addressList){
        try(BufferedReader addressInputReader = new BufferedReader(new FileReader(ADDRESSES_PATH))){
            String line;
            Integer lineCounter = 1;

            String tmpCity = "";
            String tmpHouseNo = "";
            String tmpStreet = "";
            Address.AddressBuilder builder = new Address.AddressBuilder();
            while((line = addressInputReader.readLine()) != null){

                switch(lineCounter%NO_OF_LINES_FOR_ADDRESSES){
                    case 1 -> {
                        builder.city(line);
                    }
                    case 2 -> {
                        builder.houseNumber(line);
                    }
                    case 0 -> {
                        builder.street(line);
                        Address tmpAddress = builder.build();
                        addressList.add(tmpAddress);
                        builder = new Address.AddressBuilder();
                    }

                }
                lineCounter++;

            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    /**
     * input method for an Address
     * @param userInput Scanner that stores user's input
     * @return created address
     */
    private static Address addressInput(Scanner userInput){
        logger.info("Unos adrese!", Main.class.getSimpleName());
        //Address tmpAddress = null;
        //Address tmpAddress;
        Optional<Address> tmpAddress = Optional.empty();
        boolean permit = false;
        do{
            permit = true;
            System.out.print("Unesite grad: ");
            String tmpCity = userInput.nextLine();

            System.out.print("Unesite ulicu: ");
            String tmpStreet = userInput.nextLine();

            System.out.print("Unesite kucni broj: ");
            String tmpHouseNo = userInput.nextLine();

            System.out.print("Unesite postanski broj: ");
            String tmpPostalCode = userInput.nextLine();

            //return new Address(tmpHouseNo, tmpStreet, tmpPostalCode, tmpCity);
            try{
                tmpAddress = Optional.ofNullable(new Address.AddressBuilder()
                        .city(tmpCity)
                        .houseNumber(tmpHouseNo)
                        .street(tmpStreet)
                        .build());
                logger.info("Pozvan je builder za adresu!", Main.class.getSimpleName());
            }
            catch (WrongCity ex){
                System.out.println(ex.getMessage());
                permit = false;
            }

        }while (permit == false);

        return tmpAddress.get();
    }


    private static void storeRead(List<Store> storeArray, List<Item> itemArray){
        try(BufferedReader storeInputReader = new BufferedReader(new FileReader(STORES_PATH))) {
            String line;
            Integer lineCounter = 1;

            Long tmpID = Long.valueOf(0);
            String tmpName = "", tmpWebAddress = "";

            while((line = storeInputReader.readLine()) != null){
                switch(lineCounter%NO_OF_LINES_FOR_STORES){
                    case 1 -> {
                        tmpID = Long.parseLong(line);
                    }
                    case 2 -> {
                        tmpName = line;
                    }
                    case 3 -> {
                        tmpWebAddress = line;
                    }
                    case 0 -> {
                        String[] lista = line.split(",");
                        Set<Item> tmpSet = new HashSet<>();
                        for(int i=0; i<lista.length; i++){
                            tmpSet.add(itemArray.get(Integer.valueOf(lista[i])-1));
                        }
                        storeArray.add(new Store(tmpName, tmpWebAddress, tmpSet, tmpID));
                    }
                }
                lineCounter++;
            }


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    /**
     * input method for stores
     * @param userInput Scanner that stores user's input
     * @param storeArray array where store information will be stored
     * @param itemArray array for items in store
     */
    private static void storeInput(Scanner userInput, List<Store> storeArray, List<Item> itemArray){
        logger.info("Unos trgovina!", Main.class.getSimpleName());
        System.out.println("UNOS TRGOVINA: ");
        for(int i=0; i< NO_OF_STORES; i++){
            userInput.nextLine();
            System.out.print("Unesite naziv: ");
            String tmpName = userInput.nextLine();

            System.out.print("ID trgovine: ");
            Long tmpID = userInput.nextLong();

            userInput.nextLine();
            System.out.print("Unesite web adresu: ");
            String tmpWebAddress = userInput.nextLine();

            Set<Item> storeItemArray = new HashSet<>();
            //itemInput(userInput, storeItemArray, categoryArray);
            itemSelection(userInput, itemArray, storeItemArray);

            storeArray.add(new Store(tmpName, tmpWebAddress, storeItemArray, tmpID));
        }
    }

    /**
     * selection of the store with the cheapest product
     * @param storeArray array that contains information about every store available
     * @return selected store
     */
    public static Store cheapestProduct(List<Store> storeArray){
        logger.info("Odabir trgovine s najjeftinijim proizvodom!", Main.class.getSimpleName());
        //Item[] tmpItemArray = new Item[NO_OF_STORES];
        List<Item> tmpItemArray = new ArrayList<>();
        for(int i=0; i<storeArray.size(); i++){
            //tmpItemArray.set(i, storeArray.get(i).lowestPrice());
            tmpItemArray.add(storeArray.get(i).lowestPrice());
        }
        BigDecimal cheapestItem = tmpItemArray.get(0).getSellingPrice();
        int index = 0;
        for(int i=1; i<tmpItemArray.size(); i++){
            BigDecimal tmp = tmpItemArray.get(i).getSellingPrice();
            if(tmp.compareTo(cheapestItem)<0){
                cheapestItem=tmp;
                index=i;
            }
        }
        return storeArray.get(index);
    }

    /**
     * selection of the factory with the biggest product
     * @param factoryArray array that contains information about every factory available
     * @return selected factory
     */
    public static Factory biggestProduct(List<Factory> factoryArray) {
        logger.info("Odabir tvornica s najvecim proizvodom!", Main.class.getSimpleName());
        //Item[] tmpItemArray = new Item[NO_OF_FACTORIES];
        List<Item> tmpItemArray = new ArrayList<>();
        for (int i = 0; i < factoryArray.size(); i++) {
            //tmpItemArray.set(i, factoryArray.get(i).biggestVolume());
            tmpItemArray.add(factoryArray.get(i).biggestVolume());
        }
        BigDecimal biggestItem = volumeCalculator(tmpItemArray.get(0));
        int index = 0;
        for (int i = 1; i < tmpItemArray.size(); i++) {
            BigDecimal tmp = volumeCalculator(tmpItemArray.get(i));
            if (tmp.compareTo(biggestItem)>0){
                biggestItem=tmp;
                index = i;
            }
        }
        return factoryArray.get(index);
    }

    /**
     * calculates volume of selected item
     * @param item desirable item
     * @return BigDecimal value of the volume
     */
    public static BigDecimal volumeCalculator(Item item){
        logger.info("Racunam volumen!", Main.class.getSimpleName());
        return item.getWidth().multiply(item.getHeight().multiply(item.getLength()));
    }

    /**
     * selection of the laptop with the shortest warranty period
     * @param itemArray array that contains all available items
     * @return selected Laptop
     */
    private static Item shortestWarrantyLaptop(List<Item> itemArray){
        logger.info("Odabir laptopa s najkracom garancijom!", Main.class.getSimpleName());
        int highest = 1000000;
        int index = 0;
        for(int i = 0; i< itemArray.size(); i++){
            if(itemArray.get(i) instanceof Laptop){
                if(((Laptop) itemArray.get(i)).getWarranty()<highest){
                    highest = ((Laptop) itemArray.get(i)).getWarranty();
                    index = i;
                }
            }
        }
        return itemArray.get(index);
    }

    /**
     * method for selecting items from item list for Factory or Store item array
     * @param userInput Scanner that stores user's input
     * @param itemArray array with all available items
     * @param secondaryItemArray item destination array
     */
    private static void itemSelection(Scanner userInput, List<Item> itemArray, Set<Item> secondaryItemArray) {
        logger.info("Izdvajanje artikala!", Main.class.getSimpleName());
        System.out.println("UNOS PREDMETA U TVORNICU!");
        int selection = 0;
        boolean permit = false;
        for(int i = 0; i<NO_OF_FACTORY_ITEMS; i++){

            do {
                permit = true;
                itemDisplay(itemArray);
                System.out.print("Unesite redni broj artikla za unos: ");
                try{
                    selection = userInput.nextInt();
                    //userInput.nextLine(); //PROVJERI
                    for(int j=0; j< secondaryItemArray.size();j++){
                        if(secondaryItemArray.contains(itemArray.get(selection-1))){
                            permit = false;
                            throw new FactoryAndStoreException("Artikl vec postoji!");
                        }
                    }
                    //secondaryItemArray.set(i, itemArray.get(selection - 1));
                    secondaryItemArray.add(itemArray.get(selection - 1));
                }
                catch (InputMismatchException ex){
                    System.out.println("Nevaljani unos! Pokusajte ponovno!");
                    logger.error("GRESKA! Artikl je vec izdvojen!", ex);
                    permit = false;
                }
                catch(FactoryAndStoreException ex1){
                    System.out.println(ex1.getMessage());
                }
            }while(permit == false);

        }
    }


}
