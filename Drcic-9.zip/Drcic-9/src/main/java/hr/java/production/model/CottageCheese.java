package hr.java.production.model;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Objects;

/**
 * class for CottagCheese that is based on Item class and implements Edible
 */
public class CottageCheese extends Item implements Edible, Serializable {
    private static final Logger logger = LoggerFactory.getLogger(CottageCheese.class);
    final int CALORIE_AMOUNT = 980; //per kilo
    BigDecimal weight; //kilogram

    /**
     * constructs an instance for CottageCheese class
     * @param name sets name variable
     * @param category sets category variable
     * @param width sets width variable
     * @param height sets height variable
     * @param length sets length variable
     * @param productionCost sets productionCost variable
     * @param sellingPrice sets sellingPrice variable
     * @param discount sets discount variable
     * @param weight sets weight variable
     */
    public CottageCheese(String name, Category category, BigDecimal width, BigDecimal height, BigDecimal length,
                         BigDecimal productionCost, BigDecimal sellingPrice,
                         Discount discount, BigDecimal weight, Long id ) {
        super(name, category, width, height, length, productionCost, sellingPrice, discount, id);
        this.weight = weight;
        logger.info("Stvoren je objekt tipa CottageCheese!", CottageCheese.class.getSimpleName());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        CottageCheese that = (CottageCheese) o;
        return CALORIE_AMOUNT == that.CALORIE_AMOUNT && Objects.equals(weight, that.weight);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), CALORIE_AMOUNT, weight);
    }

    public BigDecimal getWeight() {
        return weight;
    }

    public void setWeight(BigDecimal weight) {
        this.weight = weight;
    }

    /**
     * overridden method from Edible interface
     * @return amount of Energetic value based on calorie constant and weight of the item
     */
    @Override
    public int calculateKiloCalories() {
        return CALORIE_AMOUNT*weight.intValue();
    }

    /**
     * overridden method form Edible interface
     * @return price based on weight and selling price of an item
     */
    @Override
    public BigDecimal calculatePrice() {
        return getSellingPrice().multiply(weight);
    }
}
