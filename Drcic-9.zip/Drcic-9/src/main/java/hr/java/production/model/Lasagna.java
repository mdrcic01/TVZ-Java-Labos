package hr.java.production.model;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Objects;

/**
 * class that Lasagna implements Edible interface
 */
public class Lasagna extends Item implements Edible, Serializable {
    private static final Logger logger = LoggerFactory.getLogger(Lasagna.class);
    final int CALORIE_AMOUNT = 1320; //per kilo
    BigDecimal weight; //kilogram

    /**
     * constructs an instance of Lasagna class
     * @param name sets a name variable
     * @param category sets a category variable
     * @param width sets a width variable
     * @param height sets a height variable
     * @param length sets a length variable
     * @param productionCost sets productionCost variable
     * @param sellingPrice sets sellingPrice variable
     * @param discount sets discount variable
     * @param weight sets weight variable
     */
    public Lasagna(String name, Category category, BigDecimal width, BigDecimal height, BigDecimal length,
                   BigDecimal productionCost, BigDecimal sellingPrice, Discount discount, BigDecimal weight, Long id) {
        super(name, category, width, height, length, productionCost, sellingPrice, discount, id);
        this.weight = weight;
        logger.info("Stvoren je objekt tipa Lasagna!", Lasagna.class.getSimpleName());
    }

    public BigDecimal getWeight() {
        return weight;
    }

    public void setWeight(BigDecimal weight) {
        this.weight = weight;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Lasagna lasagna = (Lasagna) o;
        return CALORIE_AMOUNT == lasagna.CALORIE_AMOUNT && Objects.equals(weight, lasagna.weight);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), CALORIE_AMOUNT, weight);
    }

    /**
     * method overridden from Edible interface
     * @return integer number of energy value with the mass included
     */
    @Override
    public int calculateKiloCalories() {
        return CALORIE_AMOUNT* weight.intValue();
    }

    /**
     * method overridden from Edible iterface
     * @return price calculated by multiplying price and weight
     */
    @Override
    public BigDecimal calculatePrice() {
        return getSellingPrice().multiply(weight);
    }
}
