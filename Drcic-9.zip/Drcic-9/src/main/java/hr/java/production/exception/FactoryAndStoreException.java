package hr.java.production.exception;

/**
 * custom checked exception
 */
public class FactoryAndStoreException extends Exception {
    String message;
    Throwable cause;

    /**
     * string constructor for FASException
     * @param message string message
     */
    public FactoryAndStoreException(String message) {
        super(message);
    }

    /**
     * string and cause constructor for FASException
     * @param message string message
     * @param cause cause of type "Throwable"
     */
    public FactoryAndStoreException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * cause constructor for FASException
     * @param cause cause of type "Throwable"
     */
    public FactoryAndStoreException(Throwable cause) {
        super(cause);
    }
}
