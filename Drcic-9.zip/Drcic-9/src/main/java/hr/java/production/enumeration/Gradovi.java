package hr.java.production.enumeration;

public enum Gradovi {
    SISAK("Sisak", "44000"),
    ZAGREB("Zagreb", "10000"),
    OSIJEK("Osijek", "31000"),
    SPLIT("Split", "21000"),
    UNKNOWN("N/A", "N/A");

    String naziv;
    String postanskiBroj;

    Gradovi(String naziv, String postanskiBroj) {
        this.naziv = naziv;
        this.postanskiBroj = postanskiBroj;
    }

    public String getNaziv() {
        return naziv;
    }

    public String getPostanskiBroj() {
        return postanskiBroj;
    }
}
