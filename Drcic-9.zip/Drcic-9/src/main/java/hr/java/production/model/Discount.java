package hr.java.production.model;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Objects;

/**
 * public record that calculates and holds discount for an item
 */
public record Discount(BigDecimal discountAmount) implements Serializable {
    private static final Logger logger = LoggerFactory.getLogger(Discount.class);

    /**
     * constructs Discount record
     * @param discountAmount sets discountAmount variable
     */
    public Discount(BigDecimal discountAmount) {
        this.discountAmount = discountAmount.divide(BigDecimal.valueOf(100));
        logger.info("Stvoren je zapis tipa Discount!", Discount.class.getSimpleName());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Discount discount = (Discount) o;
        return Objects.equals(discountAmount, discount.discountAmount);
    }

    @Override
    public int hashCode() {
        return Objects.hash(discountAmount);
    }

    /**
     * getter method for discount amount
     * @return disountAmount variable
     */
    @Override
    public BigDecimal discountAmount() {
        return discountAmount;
    }
}
