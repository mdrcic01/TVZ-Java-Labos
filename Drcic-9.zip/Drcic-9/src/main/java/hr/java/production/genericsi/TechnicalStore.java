package hr.java.production.genericsi;

import hr.java.production.model.Item;
import hr.java.production.model.Laptop;
import hr.java.production.model.Store;
import hr.java.production.model.Technical;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class TechnicalStore <T extends Technical> extends Store {
    public List<T> itemList;

    /**
     * constructs an instance of the class
     *
     * @param name       name of the store
     * @param webAddress web address of the store (www.xxxxxx.com)
     * @param items      array of items in the store
     */
    public TechnicalStore(String name, String webAddress, Set<Item> items, Long id) {
        super(name, webAddress, items, id);
        List <Item> tmp = items.stream().toList();
        List<T> list = new ArrayList<>();
        for (Item i : tmp) {
            if (i instanceof Laptop) {
                list.add((T) i);
            }
        }
        itemList = list;


    }

    public List<T> getItemList() {
        return itemList;
    }

    public void setItemList(List<T> itemList) {
        this.itemList = itemList;
    }
}
