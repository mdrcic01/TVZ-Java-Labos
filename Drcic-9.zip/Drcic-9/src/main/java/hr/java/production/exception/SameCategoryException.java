package hr.java.production.exception;

/**
 * custom unchecked exception
 */
public class SameCategoryException extends RuntimeException {
    Throwable cause;

    /**
     * message constructor for SCException
     * @param message string message
     */
    public SameCategoryException(String message) {
        super(message);
    }

    /**
     * message and cause constructor for SCException
     * @param message string message
     * @param cause cause of type "Throwable"
     */
    public SameCategoryException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * cause constructor for SCException
     * @param cause cause of type "Throwable"
     */
    public SameCategoryException(Throwable cause) {
        super(cause);
    }
}
