package hr.java.production.model;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Objects;

/**
 * class for storing names as an object from an extended class
 */
public class NamedEntity {
    private static final Logger logger = LoggerFactory.getLogger(NamedEntity.class);
    String name;
    Long id;

    /**
     * constructor for class Named entity
     * @param name stores a name to variable
     */
    public NamedEntity(String name, Long id) {
        this.id = id;
        this.name = name;
        logger.info("Stvoren je objekt tipa NamedEntity!", NamedEntity.class.getSimpleName());
    }
    public NamedEntity(String name) {
        this.id = null;
        this.name = name;
        logger.info("Stvoren je objekt tipa NamedEntity!", NamedEntity.class.getSimpleName());
    }
    public NamedEntity(){

    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        NamedEntity that = (NamedEntity) o;
        return Objects.equals(name, that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
