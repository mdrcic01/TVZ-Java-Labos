package hr.java.production.model;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/**
 * public class Factory that extends NamedEntity
 */
public class Factory extends NamedEntity implements Serializable {
    private static final Logger logger = LoggerFactory.getLogger(Factory.class);
    Address address;
    Set<Item> items;

    /**
     * constructs an instance of a Factory class
     * @param name sets name variable
     * @param address sets an Address object
     * @param items sets an Item array
     */
    public Factory(String name, Address address, Set<Item> items, Long id) {
        super(name, id);
        this.address = address;
        this.items = items;
        logger.info("Stvoren je objekt tipa Factory!", Factory.class.getSimpleName());
    }
    public Factory(String name, Address address, Set<Item> items) {
        super(name);
        this.address = address;
        this.items = items;
        logger.info("Stvoren je objekt tipa Factory!", Factory.class.getSimpleName());
    }

    public Factory(){

    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public Set<Item> getItems() {
        return items;
    }

    @Override
    public String toString() {
        return "Factory{" +
                "address=" + address +
                ", items=" + items +
                ", name='" + name + '\'' +
                ", id=" + id +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Factory factory = (Factory) o;
        return Objects.equals(address, factory.address) && Objects.equals(items, factory.items);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), address, items);
    }

    public void setItems(Set<Item> items) {
        this.items = items;
    }

    /**
     * method that calculates biggest item by volume in a single instance
     * @return single Item object from Factory's Item array
     */
    public Item biggestVolume(){
        List<Item> items = this.items.stream().toList();
        logger.info("Racunam najveci obujam!", Factory.class.getSimpleName());
        int index = 0;
        BigDecimal target = items.get(0).width.multiply(items.get(0).height.multiply(items.get(0).length));
        BigDecimal tmp;

        for(int i=1; i<items.size();i++){

            tmp = items.get(i).width.multiply(items.get(i).height.multiply(items.get(i).length));

            if (tmp.compareTo(target)>0) {

                target = tmp;
                index = i;

            }
        }
        return items.get(index);
    }
}
