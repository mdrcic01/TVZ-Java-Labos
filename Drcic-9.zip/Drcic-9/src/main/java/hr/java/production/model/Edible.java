package hr.java.production.model;

import java.math.BigDecimal;

/**
 * interface that is implemented by classed of Edible items
 */
public interface Edible {
    /**
     * method that calculates Energy value from weight of the item
     * @return integer value of energy
     */
    int calculateKiloCalories();

    /**
     * method that calculates selling price based on weight of the item
     * @return BigDecimal value of price
     */
    BigDecimal calculatePrice();
}
