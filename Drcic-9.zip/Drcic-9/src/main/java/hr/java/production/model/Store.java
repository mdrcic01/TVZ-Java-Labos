package hr.java.production.model;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/**
 * public class that extends NamedEntity class
 */
public class Store extends NamedEntity implements Serializable {
    private static final Logger logger = LoggerFactory.getLogger(Store.class);
    String webAddress;
    Set<Item> items;

    /**
     * constructs an instance of the class
     * @param name name of the store
     * @param webAddress web address of the store (www.xxxxxx.com)
     * @param items array of items in the store
     */
    public Store(String name, String webAddress, Set<Item> items, Long id) {
        super(name, id);
        this.webAddress = webAddress;
        this.items = items;
        logger.info("Stvoren je objekt tipa Store!", Store.class.getSimpleName());
    }
    public Store(String name, String webAddress, Set<Item> items) {
        super(name);
        this.webAddress = webAddress;
        this.items = items;
        logger.info("Stvoren je objekt tipa Store!", Store.class.getSimpleName());
    }

    public String getWebAddress() {
        return webAddress;
    }

    public void setWebAddress(String webAddress) {
        this.webAddress = webAddress;
    }

    public Set<Item> getItems() {
        return items;
    }

    public void setItems(Set<Item> items) {
        this.items = items;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Store store = (Store) o;
        return Objects.equals(webAddress, store.webAddress) && Objects.equals(items, store.items);
    }

    @Override
    public String toString() {
        return "Store{" +
                "name='" + name + '\'' +
                ", id=" + id +
                ", webAddress='" + webAddress + '\'' +
                ", items=" + items +
                '}';
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), webAddress, items);
    }

    /**
     * calculates an item with the lowest price in a single instance
     * @return single Item from stores array
     */
    public Item lowestPrice(){
        logger.info("Trazim predmet s najmanjom cijenom!", Store.class.getSimpleName());
        List<Item> items = this.items.stream().toList();
        BigDecimal target = items.get(0).sellingPrice;
        int index = 0;
        BigDecimal tmp;

        for(int i=1; i< items.size(); i++){

            tmp = items.get(i).sellingPrice;

            if(tmp.compareTo(target)<0){

                target = tmp;
                index = i;

            }
        }

        return items.get(index);
    }
}
