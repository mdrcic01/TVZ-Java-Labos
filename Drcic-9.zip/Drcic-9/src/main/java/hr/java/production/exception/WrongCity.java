package hr.java.production.exception;

public class WrongCity extends RuntimeException{

    public WrongCity(String message) {
        super(message);
    }
}
