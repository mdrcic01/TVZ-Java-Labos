package hr.java.production.model;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.util.Objects;

/**
 * category class that will hold all available categories
 */
public class Category extends NamedEntity implements Serializable {
    private static final Logger logger = LoggerFactory.getLogger(Category.class);
    String description;

    /**
     * constructs an instance of a category class
     * @param name sets name variable
     * @param description sets description variable
     */
    public Category(String name, String description,Long id) {
        super(name, id);
        this.name = name;
        this.description = description;
        logger.info("Stvoren je objekt tipa Category!", Category.class.getSimpleName());
    }
    public Category(String name, String description) {
        super(name);
        this.name = name;
        this.description = description;
        logger.info("Stvoren je objekt tipa Category!", Category.class.getSimpleName());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Category category = (Category) o;
        return Objects.equals(description, category.description);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), description);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "Category{" +
                "description='" + description + '\'' +
                ", name='" + name + '\'' +
                ", id=" + id +
                '}';
    }
}
