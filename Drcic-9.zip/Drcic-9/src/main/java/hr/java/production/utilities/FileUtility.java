package hr.java.production.utilities;

import hr.java.production.model.*;

import java.io.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class FileUtility {
    private static final String ITEM_FILE_PATH = "dat/items.txt";
    private static final String CATEGORY_FILE_PATH = "dat/categories.txt";
    private static final String FACTORY_FILE_PATH = "dat/factories.txt";
    private static final String ADDRESS_FILE_PATH = "dat/addresses.txt";
    private static final String STORE_FILE_PATH = "dat/stores.txt";

    public static List<Category> getCategoryList() throws IOException{
        FileReader reader = new FileReader(CATEGORY_FILE_PATH);
        List<Category> categoryList = new ArrayList<>();
        BufferedReader br = new BufferedReader(reader);
        String readLine;
        while((readLine = br.readLine()) != null){
            Long tmpID = Long.parseLong(readLine);
            String tmpName = br.readLine();
            String tmpDescription = br.readLine();
            Category tmpCategory = new Category(tmpName, tmpDescription, tmpID);
            categoryList.add(tmpCategory);
        }

        return categoryList;
    }

    public static List<Item> getItemList() throws IOException {
        FileReader reader = new FileReader(ITEM_FILE_PATH);
        List<Item> itemList = new ArrayList<>();
        BufferedReader br = new BufferedReader(reader);
        String readLine;
        while((readLine = br.readLine()) != null){
            Long tmpID = Long.parseLong(readLine);
            String tmpName = br.readLine();
            String tmpCategory = br.readLine();
            BigDecimal tmpWidth = BigDecimal.valueOf(Double.parseDouble(br.readLine()));
            BigDecimal tmpHeight = BigDecimal.valueOf(Double.parseDouble(br.readLine()));
            BigDecimal tmpLength = BigDecimal.valueOf(Double.parseDouble(br.readLine()));
            BigDecimal tmpProductionCost = BigDecimal.valueOf(Double.parseDouble(br.readLine()));
            BigDecimal tmpSellingPrice = BigDecimal.valueOf(Double.parseDouble(br.readLine()));
            Discount tmpDiscount = new Discount(BigDecimal.valueOf(Double.parseDouble(br.readLine())));
            Category tmpCategory1 = null;
            List<Category> categoryList = getCategoryList();
            for(int i = 0; i<categoryList.size(); i++){
                if(tmpCategory.equals(categoryList.get(i).getName())){
                    tmpCategory1 = categoryList.get(i);
                }
            }
            Item tmpItem = new Item(tmpName, tmpCategory1, tmpWidth, tmpHeight, tmpLength, tmpProductionCost,
                    tmpSellingPrice, tmpDiscount, tmpID);
            itemList.add(tmpItem);
        }

        return itemList;

    }

    public static List<Factory> getFactoryList() throws IOException{
        FileReader reader = new FileReader(FACTORY_FILE_PATH);
        List<Factory> factoryList = new ArrayList<>();
        BufferedReader br = new BufferedReader(reader);

        String readLine;

        /*1
        SisakTvornica
        2
        1,2,3,4,5*/

        /*String[] lista = line.split(",");
        Set<Item> tmpSet = new HashSet<>();
        for(int i=0; i<lista.length; i++){
            tmpSet.add(itemArray.get(Integer.parseInt(lista[i])-1));
        }
        factoryArray.add(new Factory(tmpName, tmpAddress, tmpSet, tmpID));*/

        List<Address> addressList = getAddressList();
        List<Item> itemList = getItemList();
        while((readLine = br.readLine())!=null){
            Long tmpID = Long.parseLong(readLine);
            String tmpName = br.readLine();
            Integer tmpAddressIndex = Integer.parseInt(br.readLine());
            Address tmpAddress = addressList.get(tmpAddressIndex-1);
            String[] lista = br.readLine().split(",");
            Set<Item> tmpSet = new HashSet<>();
            for(int i=0; i< lista.length; i++){
                tmpSet.add(itemList.get(Integer.parseInt(lista[i])-1));
            }
            Factory tmpFactory = new Factory(tmpName, tmpAddress, tmpSet, tmpID);
            factoryList.add(tmpFactory);
        }

        return factoryList;
    }

    public static List<Store> getStoreList() throws IOException {
        FileReader reader = new FileReader(STORE_FILE_PATH);
        BufferedReader br = new BufferedReader(reader);
        String readLine;
        List<Store> storeList = new ArrayList<>();
        List<Item> itemList = getItemList();
        while ((readLine = br.readLine()) != null){
            Long tmpID = Long.parseLong(readLine);
            String tmpName = br.readLine();
            String tmpAddress = br.readLine();
            String[] lista = br.readLine().split(",");
            Set<Item> itemSet = new HashSet<>();
            for(int i=0; i< lista.length; i++){
                itemSet.add(itemList.get(Integer.parseInt(lista[i])-1));
            }
            Store tmpStore = new Store(tmpName, tmpAddress, itemSet, tmpID);
            storeList.add(tmpStore);
        }
        return storeList;
    }

    public static List<Address> getAddressList() throws IOException{
        FileReader reader = new FileReader(ADDRESS_FILE_PATH);
        BufferedReader br = new BufferedReader(reader);
        List<Address> addressList = new ArrayList<>();
        String readLine;

        /*Zagreb
        123
        Vukoviceva*/

        while((readLine = br.readLine()) != null){
            String tmpCity = readLine;
            String tmpHouseNo = br.readLine();
            String tmpStreet = br.readLine();
            Address.AddressBuilder tmpBuild = new Address.AddressBuilder()
                    .city(tmpCity)
                    .houseNumber(tmpHouseNo)
                    .street(tmpStreet);
            Address tmpAddress = tmpBuild.build();
            addressList.add(tmpAddress);

        }
        return addressList;

    }

    public static void saveItems(List<Item> itemList) throws IOException{
        FileWriter writer = new FileWriter(ITEM_FILE_PATH);
        PrintWriter printWriter = new PrintWriter(writer);


        for(Item item : itemList){
            printWriter.println(item.getId());
            printWriter.println(item.getName());
            printWriter.println(item.getCategory().getName());
            printWriter.println(item.getWidth());
            printWriter.println(item.getHeight());
            printWriter.println(item.getLength());
            printWriter.println(item.getProductionCost());
            printWriter.println(item.getSellingPrice());
            printWriter.println(item.getDiscount().discountAmount());
        }
        writer.flush();
    }

    public static void saveCategories(List<Category> categoryList) throws IOException {
        FileWriter writer = new FileWriter(CATEGORY_FILE_PATH);
        PrintWriter printWriter = new PrintWriter(writer);

        for(Category category : categoryList){
            printWriter.println(category.getId());
            printWriter.println(category.getName());
            printWriter.println(category.getDescription());
        }
        writer.flush();
    }

    public static void saveFactories(List<Factory> factoryList) throws IOException {
        FileWriter writer = new FileWriter(FACTORY_FILE_PATH);
        PrintWriter printWriter = new PrintWriter(writer);

        List<Address> addressList = getAddressList();
        List<Item> itemList = getItemList();

        for(Factory factory : factoryList){
            printWriter.println(factory.getId());
            printWriter.println(factory.getName());
            for(int i = 0; i<addressList.size(); i++){
                if(factory.getAddress().equals(addressList.get(i))){
                    printWriter.println(i+1);
                }
            }
            List<Integer> indexes = new ArrayList<>();
            for(Item item : factory.getItems()){
                for(int i = 0; i< itemList.size(); i++){
                    if(item.equals(itemList.get(i))){
                        indexes.add(i+1);
                    }
                }
            }
            for(int i = 0; i < indexes.size(); i++){
                if(i != indexes.size()-1){
                    printWriter.print(indexes.get(i) + ",");
                }
                else{
                    printWriter.print(indexes.get(i));
                    printWriter.println();
                }
            }
        }
        writer.flush();
    }

    public static void saveStores(List<Store> storeList) throws IOException {
        FileWriter writer = new FileWriter(STORE_FILE_PATH);
        PrintWriter printWriter = new PrintWriter(writer);

        List<Item> itemList = getItemList();

        for(Store store : storeList){
            printWriter.println(store.getId());
            printWriter.println(store.getName());
            printWriter.println(store.getWebAddress());
            List<Integer> indices = new ArrayList<>();
            for(Item item : store.getItems()){
                for(int i = 0; i< itemList.size(); i++){
                    if(item.equals(itemList.get(i))){
                        indices.add(i+1);
                    }
                }
            }
            for(int i = 0; i< indices.size(); i++){
                if(i!=indices.size()-1){
                    printWriter.print(indices.get(i) + ",");
                }
                else{
                    printWriter.print(indices.get(i));
                    printWriter.println();
                }
            }

        }
        writer.flush();
    }

}
