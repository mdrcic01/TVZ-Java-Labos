package hr.java.production.model;

/**
 * permits only Laptop class
 * contains warrantyDuration method
 */
public sealed interface Technical permits Laptop {
    /**
     *
     * @return duration of warranty in months
     */
    int warrantyDuration(); // u mjesecima
}
