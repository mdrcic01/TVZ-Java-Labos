module com.example.drcic8 {
    requires javafx.controls;
    requires javafx.fxml;
    requires org.slf4j;
    requires java.sql;

    opens com.example.drcic7 to javafx.fxml;
    exports com.example.drcic7;
}