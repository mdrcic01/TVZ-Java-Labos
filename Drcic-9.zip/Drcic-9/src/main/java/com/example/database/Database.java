package com.example.database;

import com.example.drcic7.ItemSearch;
import hr.java.production.model.*;

import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.*;
import java.util.*;

public class Database {
    public static Connection connectToDatabase() throws SQLException, IOException {
        Properties configuration = new Properties();
        configuration.load(new FileReader("dat/database.properties"));

        String databaseURL = configuration.getProperty("databaseURL");
        String databaseUsername = configuration.getProperty("username");
        String databasePassword = configuration.getProperty("password");

        Connection connection = DriverManager.getConnection(databaseURL, databaseUsername, databasePassword);
        return connection;
    }

    public static List<Category> importCategoriesFromDB() throws SQLException, IOException {
        Connection connection = connectToDatabase();
        List<Category> categoryList = new ArrayList<>();
        Statement sqlStatement = connection.createStatement();
        ResultSet rs = sqlStatement.executeQuery("SELECT * FROM CATEGORY");

        while(rs.next()){
            Long tmpID = rs.getLong("ID");
            String tmpName = rs.getString("NAME");
            String tmpDescription = rs.getString("DESCRIPTION");

            Category tmpCategory = new Category(tmpName, tmpDescription, tmpID);
            categoryList.add(tmpCategory);
        }
        rs.close();
        closeConnectionToDB(connection);
        return categoryList;
    }

    public static List<Address> getAddressListFromDB() throws SQLException, IOException {
        Connection connection = connectToDatabase();
        List<Address> addressList = new ArrayList<>();
        Statement sqlStatement = connection.createStatement();
        ResultSet rs = sqlStatement.executeQuery("SELECT * FROM ADDRESS");

        while(rs.next()){
            String tmpCity = rs.getString("CITY");
            String tmpStreet = rs.getString("STREET");
            String tmpHouseNo = rs.getString("HOUSE_NUMBER");
            String tmpPostalCode = rs.getString("POSTAL_CODE");
            Long tmpID = rs.getLong("ID");
            Address.AddressBuilder tmpBuild = new Address.AddressBuilder()
                    .city(tmpCity)
                    .street(tmpStreet)
                    .postalCode(tmpPostalCode)
                    .houseNumber(tmpHouseNo)
                    .id(tmpID);
            Address tmpAddress = tmpBuild.build();
            addressList.add(tmpAddress);
        }
        rs.close();
        closeConnectionToDB(connection);

        return addressList;
    }

    public static List<Item> getItemListFromDB() throws SQLException, IOException {
        Connection connection = connectToDatabase();
        List<Item> itemList = new ArrayList<>();
        Statement sqlStatement = connection.createStatement();
        ResultSet rs = sqlStatement.executeQuery("SELECT * FROM ITEM");

        List<Category> categoryList = importCategoriesFromDB();
        while(rs.next()){
            //Category tmpCategory = categoryList.get(rs.getInt("CATEGORY_ID")-1);
            Category tmpCategory = null;
            Long catID = rs.getLong("CATEGORY_ID");
            for(Category category : categoryList){
                if(category.getId() == catID){
                    tmpCategory = category;
                }
            }
            String tmpName = rs.getString("NAME");
            BigDecimal tmpWidth = rs.getBigDecimal("WIDTH");
            BigDecimal tmpHeight = rs.getBigDecimal("HEIGHT");
            BigDecimal tmpLength = rs.getBigDecimal("LENGTH");
            BigDecimal tmpProductionCost = rs.getBigDecimal("PRODUCTION_COST");
            BigDecimal tmpSellingPrice = rs.getBigDecimal("SELLING_PRICE");
            Long tmpID = rs.getLong("ID");

            Item tmpItem = new Item(tmpName, tmpCategory, tmpWidth, tmpHeight, tmpLength, tmpProductionCost,
                    tmpSellingPrice, new Discount(BigDecimal.ZERO), tmpID);
            itemList.add(tmpItem);
        }

        rs.close();
        closeConnectionToDB(connection);
        return itemList;
    }

    public static List<Factory> getFactoryListFromDB() throws SQLException, IOException {
        Connection connection = connectToDatabase();
        List<Factory> factoryList = new ArrayList<>();
        Statement sqlStatement = connection.createStatement();
        ResultSet rs = sqlStatement.executeQuery("SELECT * FROM FACTORY");

        List<Address> addressList = getAddressListFromDB();
        while(rs.next()){
            String tmpName = rs.getString("NAME");
            Long addressID = rs.getLong("ADDRESS_ID");
            //Address tmpAddress = addressList.get(rs.getInt("ADDRESS_ID")-1);
            Address tmpAddress = null;
            for(Address address : addressList){
                if(addressID == address.getID()){
                    tmpAddress = address;
                }
            }
            Long tmpID = rs.getLong("ID");
            Set<Item> itemSet = getFactoryItemSetFromDB(tmpID);
            Factory tmpFactory = new Factory(tmpName, tmpAddress, itemSet, tmpID);
            factoryList.add(tmpFactory);
        }

        rs.close();
        closeConnectionToDB(connection);
        return factoryList;
    }

    public static Factory getSingleFactoryFromDB(String searchName, Connection connection) throws SQLException {
        Statement stmt = connection.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM FACTORY");

        Factory tmpFactory = null;
        List<Address> addressList = null;
        try {
            addressList = getAddressListFromDB();
        } catch (IOException e) {
            e.printStackTrace();
        }
        while(rs.next()){
            if(rs.getString("NAME").equals(searchName)){
                String tmpName = rs.getString("NAME");
                Long addressID = rs.getLong("ADDRESS_ID");
                //Address tmpAddress = addressList.get(rs.getInt("ADDRESS_ID")-1);
                Address tmpAddress = null;
                for(Address address : addressList){
                    if(addressID == address.getID()){
                        tmpAddress = address;
                    }
                }
                Long tmpID = rs.getLong("ID");
                Set<Item> itemSet = null;
                try {
                    itemSet = getFactoryItemSetFromDB(tmpID);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                tmpFactory = new Factory(tmpName, tmpAddress, itemSet, tmpID);
            }
        }
        rs.close();
        return tmpFactory;
    }

    public static Store getSingleStoreFromDB(String searchName, Connection connection) throws SQLException {
        Statement stmt = connection.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM STORE");

        Store tmpStore = null;
        while(rs.next()){
            if(rs.getString("NAME").equals(searchName)){
                String tmpName = rs.getString("NAME");
                String tmpAddress = rs.getString("WEB_ADDRESS");
                Long tmpID = rs.getLong("ID");
                Set<Item> tmpSet = null;
                try {
                    tmpSet = getStoreItemSetFromDB(tmpID);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                tmpStore = new Store(tmpName, tmpAddress, tmpSet, tmpID);
            }
        }
        rs.close();
        return tmpStore;
    }

    public static List<Store> getStoreListFromDB() throws SQLException, IOException {
        Connection connection = connectToDatabase();
        Statement sqlStatement = connection.createStatement();
        ResultSet rs = sqlStatement.executeQuery("SELECT * FROM STORE");
        List<Store> storeList = new ArrayList<>();

        while(rs.next()){
            String tmpName = rs.getString("NAME");
            String tmpAddress = rs.getString("WEB_ADDRESS");
            Long tmpID = rs.getLong("ID");
            Set<Item> tmpSet = getStoreItemSetFromDB(tmpID);
            Store tmpStore = new Store(tmpName, tmpAddress, tmpSet, tmpID);
            storeList.add(tmpStore);
        }
        rs.close();
        closeConnectionToDB(connection);
        return storeList;
    }

    public static Set<Item> getFactoryItemSetFromDB(Long id) throws SQLException, IOException {
        Set<Item> itemSet = new HashSet<>();
        Connection connection = connectToDatabase();
        Statement sqlStatement = connection.createStatement();
        ResultSet rs = sqlStatement.executeQuery("SELECT * FROM FACTORY_ITEM");
        List<Item> itemList = getItemListFromDB();
        while(rs.next()){
            if(rs.getLong("FACTORY_ID") == id){
                for(Item item : itemList){
                    if(item.getId().equals(rs.getLong("ITEM_ID"))){
                        itemSet.add(item);
                    }
                }
            }
        }
        rs.close();
        closeConnectionToDB(connection);
        return itemSet;
    }

    public static Set<Item> getStoreItemSetFromDB(Long id) throws SQLException, IOException {
        Connection connection = connectToDatabase();
        Set<Item> itemSet = new HashSet<>();
        Statement sqlStatement = connection.createStatement();
        ResultSet rs = sqlStatement.executeQuery("SELECT * FROM STORE_ITEM");

        List<Item> itemList = getItemListFromDB();
        while(rs.next()){
            if(rs.getLong("STORE_ID") == id){
                for(Item item : itemList){
                    if(item.getId().equals(rs.getLong("ITEM_ID"))){
                        itemSet.add(item);
                    }
                }
            }
        }
        rs.close();
        closeConnectionToDB(connection);
        return itemSet;
    }

    public static void insertCategoryIntoDB(Category category) throws SQLException, IOException {
        Connection connection = connectToDatabase();

        PreparedStatement stmt =
                connection.prepareStatement("INSERT INTO CATEGORY (NAME, DESCRIPTION) VALUES(?, ?)");

        stmt.setString(1, category.getName());
        stmt.setString(2, category.getDescription());

        stmt.executeUpdate();

        closeConnectionToDB(connection);
    }

    public static void insertItemsIntoDB(Item item) throws SQLException, IOException {
        Connection connection = connectToDatabase();

        PreparedStatement stmt = connection.prepareStatement("INSERT INTO ITEM (CATEGORY_ID, NAME, WIDTH, " +
                "HEIGHT, LENGTH, PRODUCTION_COST, SELLING_PRICE) VALUES(?, ?, ?, ?, ?, ?, ?)");
        List<Category> categoryList = importCategoriesFromDB();
        Long categoryID = Long.valueOf(0);
        for(Category category : categoryList){
            if(item.getCategory().equals(category)){
                categoryID = category.getId();
            }
        }

        stmt.setString(1, String.valueOf(categoryID));
        stmt.setString(2, item.getName());
        stmt.setString(3, String.valueOf(item.getWidth()));
        stmt.setString(4, String.valueOf(item.getHeight()));
        stmt.setString(5, String.valueOf(item.getLength()));
        stmt.setString(6, String.valueOf(item.getProductionCost()));
        stmt.setString(7, String.valueOf(item.getSellingPrice()));

        stmt.executeUpdate();

        closeConnectionToDB(connection);
    }

    public static void insertFactoryIntoDB(Factory factory) throws SQLException, IOException {
        Connection connection = connectToDatabase();

        PreparedStatement stmt =
                connection.prepareStatement("INSERT INTO FACTORY(NAME, ADDRESS_ID) VALUES(?, ?)");

        stmt.setString(1, factory.getName());
        List<Address> addressList = getAddressListFromDB();
        Long addressID = Long.valueOf(0);
        for(Address address : addressList){
            if(factory.getAddress().equals(address)){
                addressID = address.getID();
            }
        }
        stmt.setString(2, String.valueOf(addressID));

        stmt.executeUpdate();
        Factory newFactory = getSingleFactoryFromDB(factory.getName(), connection);
        for(Item item : factory.getItems()){
            PreparedStatement stmt1 =
                    connection.prepareStatement("INSERT INTO FACTORY_ITEM(FACTORY_ID, ITEM_ID) VALUES(?, ?)");
            Long factoryID = newFactory.getId();
            Long itemID = item.getId();
            stmt1.setString(1, String.valueOf(factoryID));
            stmt1.setString(2, String.valueOf(itemID));
            stmt1.executeUpdate();
        }
        closeConnectionToDB(connection);
    }

    public static void insertStoreIntoDB(Store store) throws SQLException, IOException {
        Connection connection = connectToDatabase();

        PreparedStatement stmt = connection.prepareStatement("INSERT INTO STORE(NAME, WEB_ADDRESS) " +
                "VALUES(?, ?)");

        stmt.setString(1, store.getName());
        stmt.setString(2, store.getWebAddress());

        stmt.executeUpdate();

        Store newStore = getSingleStoreFromDB(store.getName(), connection);
        for(Item item : store.getItems()){
            PreparedStatement stmt1 =
                    connection.prepareStatement("INSERT INTO STORE_ITEM(STORE_ID, ITEM_ID) VALUES(?, ?)");

            stmt1.setString(1, String.valueOf(newStore.getId()));
            stmt1.setString(2, String.valueOf(item.getId()));

            stmt1.executeUpdate();
        }

        closeConnectionToDB(connection);
    }

    public static Item getSingleItemWithIDFromDB(Long ID) throws SQLException, IOException {
        Connection connection = connectToDatabase();
        PreparedStatement stmt = connection.prepareStatement("SELECT * FROM ITEM WHERE ID = ?;");
        stmt.setString(1, String.valueOf(ID));
        //stmt.executeUpdate();
        ResultSet rs = stmt.executeQuery();
        Item tmpItem = null;
        List<Category> categoryList = importCategoriesFromDB();
        while(rs.next()){
            if(ID.equals(rs.getLong("ID"))){
                Category tmpCategory = null;
                Long catID = rs.getLong("CATEGORY_ID");
                for(Category category : categoryList){
                    if(category.getId() == catID){
                        tmpCategory = category;
                    }
                }
                String tmpName = rs.getString("NAME");
                BigDecimal tmpWidth = rs.getBigDecimal("WIDTH");
                BigDecimal tmpHeight = rs.getBigDecimal("HEIGHT");
                BigDecimal tmpLength = rs.getBigDecimal("LENGTH");
                BigDecimal tmpProductionCost = rs.getBigDecimal("PRODUCTION_COST");
                BigDecimal tmpSellingPrice = rs.getBigDecimal("SELLING_PRICE");
                Long tmpID = rs.getLong("ID");

                tmpItem = new Item(tmpName, tmpCategory, tmpWidth, tmpHeight, tmpLength, tmpProductionCost,
                        tmpSellingPrice, new Discount(BigDecimal.ZERO), tmpID);
            }
        }

        rs.close();
        closeConnectionToDB(connection);
        return tmpItem;
    }

    public static Category getSingleCategoryWithIDFromDB(Long ID) throws SQLException, IOException {
        Connection connection = connectToDatabase();
        PreparedStatement stmt = connection.prepareStatement("SELECT * FROM CATEGORY WHERE ID = ?;");
        stmt.setString(1, String.valueOf(ID));
        ResultSet rs = stmt.executeQuery();

        Category tmpCategory = null;
        while(rs.next()){
            if(ID.equals(rs.getLong("ID"))){
                String tmpName = rs.getString("NAME");
                String tmpDescription = rs.getString("DESCRIPTION");
                Long tmpID = rs.getLong("ID");

                tmpCategory = new Category(tmpName, tmpDescription, tmpID);
            }
        }

        rs.close();
        closeConnectionToDB(connection);
        return tmpCategory;
    }

    public static Factory getSingleFactoryWithIDFromDB(Long ID) throws SQLException, IOException {
        Connection connection = connectToDatabase();
        PreparedStatement stmt = connection.prepareStatement("SELECT * FROM FACTORY WHERE ID = ?;");
        stmt.setString(1, String.valueOf(ID));
        ResultSet rs = stmt.executeQuery();

        Factory tmpFactory = null;
        List<Address> addressList = null;
        try {
            addressList = getAddressListFromDB();
        } catch (IOException e) {
            e.printStackTrace();
        }
        while(rs.next()){
            if(ID.equals(rs.getLong("ID"))){
                String tmpName = rs.getString("NAME");
                Long addressID = rs.getLong("ADDRESS_ID");
                //Address tmpAddress = addressList.get(rs.getInt("ADDRESS_ID")-1);
                Address tmpAddress = null;
                for(Address address : addressList){
                    if(addressID == address.getID()){
                        tmpAddress = address;
                    }
                }
                Long tmpID = rs.getLong("ID");
                Set<Item> itemSet = null;
                try {
                    itemSet = getFactoryItemSetFromDB(tmpID);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                tmpFactory = new Factory(tmpName, tmpAddress, itemSet, tmpID);
            }
        }
        rs.close();
        closeConnectionToDB(connection);
        return tmpFactory;
    }

    public static Store getSingleStoreWithIDFromDB(Long ID) throws SQLException, IOException {
        Connection connection = connectToDatabase();
        PreparedStatement stmt = connection.prepareStatement("SELECT * FROM STORE WHERE ID = ?;");
        stmt.setString(1, String.valueOf(ID));
        ResultSet rs = stmt.executeQuery();

        Store tmpStore = null;
        while(rs.next()){
            if(ID.equals(rs.getLong("ID"))){
                String tmpName = rs.getString("NAME");
                String tmpAddress = rs.getString("WEB_ADDRESS");
                Long tmpID = rs.getLong("ID");
                Set<Item> tmpSet = null;
                try {
                    tmpSet = getStoreItemSetFromDB(tmpID);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                tmpStore = new Store(tmpName, tmpAddress, tmpSet, tmpID);
            }
        }
        rs.close();
        closeConnectionToDB(connection);
        return tmpStore;
    }

    public static Set<Item> getFactoryItemsFromDBAlternative(Long id) throws SQLException, IOException {
        Connection connection = connectToDatabase();

        PreparedStatement stmt = connection.prepareStatement("SELECT * FROM FACTORY_ITEM FI, ITEM I " +
                "WHERE FI.FACTORY_ID = ? AND FI.ITEM_ID = I.ID;");
        stmt.setString(1, String.valueOf(id));
        ResultSet rs = stmt.executeQuery();
        Set<Item> itemSet = new HashSet<>();
        List<Category> categoryList = importCategoriesFromDB();
        while(rs.next()){
            //Category tmpCategory = categoryList.get(rs.getInt("CATEGORY_ID")-1);
            Category tmpCategory = null;
            Long catID = rs.getLong("CATEGORY_ID");
            for(Category category : categoryList){
                if(category.getId() == catID){
                    tmpCategory = category;
                }
            }
            String tmpName = rs.getString("NAME");
            BigDecimal tmpWidth = rs.getBigDecimal("WIDTH");
            BigDecimal tmpHeight = rs.getBigDecimal("HEIGHT");
            BigDecimal tmpLength = rs.getBigDecimal("LENGTH");
            BigDecimal tmpProductionCost = rs.getBigDecimal("PRODUCTION_COST");
            BigDecimal tmpSellingPrice = rs.getBigDecimal("SELLING_PRICE");
            Long tmpID = rs.getLong("ID");

            Item tmpItem = new Item(tmpName, tmpCategory, tmpWidth, tmpHeight, tmpLength, tmpProductionCost,
                    tmpSellingPrice, new Discount(BigDecimal.ZERO), tmpID);
            itemSet.add(tmpItem);
        }

        rs.close();
        closeConnectionToDB(connection);
        return itemSet;
    }

    public static Set<Item> getStoreItemsFromDBAlternative(Long id) throws SQLException, IOException {
        Connection connection = connectToDatabase();
        PreparedStatement stmt = connection.prepareStatement("SELECT * FROM STORE_ITEM SI, ITEM I " +
                "WHERE SI.STORE_ID = ? AND SI.ITEM_ID = I.ID;");
        stmt.setString(1, String.valueOf(id));
        ResultSet rs = stmt.executeQuery();
        Set<Item> itemSet = new HashSet<>();
        List<Category> categoryList = importCategoriesFromDB();
        while(rs.next()){
            //Category tmpCategory = categoryList.get(rs.getInt("CATEGORY_ID")-1);
            Category tmpCategory = null;
            Long catID = rs.getLong("CATEGORY_ID");
            for(Category category : categoryList){
                if(category.getId() == catID){
                    tmpCategory = category;
                }
            }
            String tmpName = rs.getString("NAME");
            BigDecimal tmpWidth = rs.getBigDecimal("WIDTH");
            BigDecimal tmpHeight = rs.getBigDecimal("HEIGHT");
            BigDecimal tmpLength = rs.getBigDecimal("LENGTH");
            BigDecimal tmpProductionCost = rs.getBigDecimal("PRODUCTION_COST");
            BigDecimal tmpSellingPrice = rs.getBigDecimal("SELLING_PRICE");
            Long tmpID = rs.getLong("ID");

            Item tmpItem = new Item(tmpName, tmpCategory, tmpWidth, tmpHeight, tmpLength, tmpProductionCost,
                    tmpSellingPrice, new Discount(BigDecimal.ZERO), tmpID);
            itemSet.add(tmpItem);
        }

        rs.close();
        closeConnectionToDB(connection);
        return itemSet;
    }

    public static void closeConnectionToDB(Connection connection) throws SQLException {
        connection.close();
    }
}
