package com.example.drcic7;

import com.example.database.Database;
import hr.java.production.model.Store;
import hr.java.production.utilities.FileUtility;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.chart.PieChart;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class StoreSearchController {
    ObservableList<Store> storeObservableList;

    {
        try {
            storeObservableList = FXCollections.observableList(Database.getStoreListFromDB());
        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public TextField storeNameTF;
    @FXML
    public TextField storeAddressTF;
    @FXML
    public TableView<Store> storeTableView;
    @FXML
    public TableColumn<Store, String> storeNameTableColumn;
    @FXML
    public TableColumn<Store, String> storeAddressTableColumn;
    @FXML
    public TableColumn<Store, Long> storeIDTableColumn;

    @FXML
    public void initialize(){
        storeNameTableColumn.setCellValueFactory(cell -> {
            return new SimpleStringProperty(cell.getValue().getName());
        });
        storeAddressTableColumn.setCellValueFactory(cell -> {
            return new SimpleStringProperty(cell.getValue().getWebAddress());
        });
        storeIDTableColumn.setCellValueFactory(cell -> {
            return new SimpleObjectProperty<>(cell.getValue().getId());
        });
        storeTableView.setItems(storeObservableList);
    }

    @FXML
    public void onStoreSearchButtonClick(){
        String tmpName = storeNameTF.getText();
        String tmpAddress = storeAddressTF.getText();
        List<Store> filteredStoreList = storeObservableList.stream()
                .filter(it -> it.getName().toLowerCase().contains(tmpName.toLowerCase()))
                .filter(it -> it.getWebAddress().toLowerCase().contains(tmpAddress.toLowerCase()))
                .collect(Collectors.toList());

        storeTableView.setItems(FXCollections.observableList(filteredStoreList));
    }


}
