package com.example.drcic7;

import com.example.database.Database;
import hr.java.production.model.Category;
import hr.java.production.model.Discount;
import hr.java.production.model.Item;
import hr.java.production.utilities.FileUtility;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AddNewItemController {
    ObservableList<Category> categoryObservableList;

    {
        try {
            categoryObservableList = FXCollections.observableList(Database.importCategoriesFromDB());
        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public Button saveButton;
    @FXML
    public TextField nameTF;
    @FXML
    public TextField widthTF;
    @FXML
    public TextField heightTF;
    @FXML
    public TextField lengthTF;
    @FXML
    public TextField productionCostTF;
    @FXML
    public TextField sellingPriceTF;
    @FXML
    public TextField discountTF;
    @FXML
    public ChoiceBox<String> categoryCB;

    public void initialize(){
        List<String> categories = new ArrayList<>();
        for(Category cat : categoryObservableList){
            categories.add(cat.getName());
        }
        categoryCB.setItems(FXCollections.observableList(categories));
        categoryCB.getSelectionModel().selectFirst();
    }

    public void onSaveButtonClick() throws IOException {

        StringBuilder errorMessages = new StringBuilder();


        String tmpName = nameTF.getText();
        if(tmpName.isEmpty()){
            errorMessages.append("Name is required!\n");
        }
        BigDecimal tmpWidth = null;
        try{
            tmpWidth = BigDecimal.valueOf(Long.parseLong(widthTF.getText()));
        }
        catch (NumberFormatException ex){
            errorMessages.append("Width must be in number format and can't be empty!\n");
        }

        BigDecimal tmpHeight = null;
        try {
            tmpHeight = BigDecimal.valueOf(Long.parseLong(heightTF.getText()));
        }
        catch (NumberFormatException ex){
            errorMessages.append("Height must be in number format and can't be empty!\n");
        }
        BigDecimal tmpLength = null;
        try{
            tmpLength = BigDecimal.valueOf(Long.parseLong(lengthTF.getText()));
        }
        catch (NumberFormatException ex){
            errorMessages.append("Length must be in number format and can't be empty!\n");
        }
        BigDecimal tmpProductionCost = null;
        try{
            tmpProductionCost = BigDecimal.valueOf(Long.parseLong(productionCostTF.getText()));
        }
        catch (NumberFormatException ex){
            errorMessages.append("Production cost must be in number format and can't be empty!\n");
        }
        BigDecimal tmpSellingPrice = null;
        try{
            tmpSellingPrice = BigDecimal.valueOf(Long.parseLong(sellingPriceTF.getText()));
        }
        catch (NumberFormatException ex){
            errorMessages.append("Selling price must be in number format and can't be empty!\n");
        }
        Discount tmpDiscount = null;
        try{
            tmpDiscount = new Discount(BigDecimal.valueOf(Long.parseLong(discountTF.getText())));
        }catch (NumberFormatException ex){
            errorMessages.append("Discount must be in number format and can't be emtpty!\n");
        }
        String tmpCategory = categoryCB.getValue();
        Category tmpCat = null;
        for (Category cat : categoryObservableList){
            if(cat.getName().equals(tmpCategory)){
                tmpCat = cat;
            }
        }
        if(errorMessages.isEmpty()){
            Item tmpItem = new Item(tmpName, tmpCat, tmpWidth, tmpHeight, tmpLength, tmpProductionCost, tmpSellingPrice,
                    tmpDiscount);

            try {
                Database.insertItemsIntoDB(tmpItem);
            } catch (SQLException e) {
                e.printStackTrace();
            }

            nameTF.clear();
            categoryCB.getSelectionModel().clearSelection();
            widthTF.clear();
            heightTF.clear();
            lengthTF.clear();
            productionCostTF.clear();
            sellingPriceTF.clear();
            discountTF.clear();

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Action successful");
            alert.setHeaderText(null);
            alert.setContentText("Your Item was saved successfully!");

            alert.showAndWait();
        }
        else{
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Action failed!");
            alert.setHeaderText(null);
            alert.setContentText(errorMessages.toString());

            alert.showAndWait();
        }
    }
}
