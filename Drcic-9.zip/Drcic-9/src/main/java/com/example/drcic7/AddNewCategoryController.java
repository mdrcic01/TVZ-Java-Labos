package com.example.drcic7;

import com.example.database.Database;
import hr.java.production.model.Category;
import hr.java.production.utilities.FileUtility;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AddNewCategoryController {
    public List<Category> categoryList;

    {
        try {
            categoryList = new ArrayList<>(Database.importCategoriesFromDB());
        } catch (IOException e) {
            e.printStackTrace();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    @FXML
    public Label ID;
    @FXML
    public TextField nameTF;
    @FXML
    public TextArea descriptionTA;

    public void initialize(){
        ID.setText(String.valueOf(categoryList.size()+1));
    }

    public void onSaveButtonClick() throws IOException {

        StringBuilder errorMessages = new StringBuilder();

        String tmpName = nameTF.getText();
        if(tmpName.isEmpty()){
            errorMessages.append("Name is required!");
        }
        String tmpDescription = descriptionTA.getText();
        if(tmpDescription.isEmpty()){
            tmpDescription = "N/A";
        }
        if(errorMessages.isEmpty()){
            Category tmpCategory = new Category(tmpName, tmpDescription);
            categoryList.add(tmpCategory);
            ID.setText(String.valueOf(categoryList.size()+1));
            //FileUtility.saveCategories(categoryList);
            try {
                Database.insertCategoryIntoDB(tmpCategory);
            } catch (SQLException e) {
                e.printStackTrace();
            }

            nameTF.clear();
            descriptionTA.clear();


            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Action successful");
            alert.setHeaderText(null);
            alert.setContentText("Your Category was saved successfully!");

            alert.showAndWait();
        }
        else{
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Action failed");
            alert.setHeaderText(null);
            alert.setContentText(errorMessages.toString());

            alert.showAndWait();
        }
    }

}
