package com.example.drcic7;

import com.example.database.Database;
import hr.java.production.model.Factory;
import hr.java.production.utilities.FileUtility;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.stream.Collectors;

public class FactorySearchController {
    @FXML
    public Button searchButton;
    @FXML
    public TextField factoryNameTF;
    @FXML
    public TextField factoryCityTF;
    @FXML
    public TableView<Factory> factoryTableView;
    @FXML
    public TableColumn<Factory, String> factoryNameColumn;
    @FXML
    public TableColumn<Factory, String> factoryCityColumn;
    @FXML
    public TableColumn<Factory, String> factoryPostalCodeColumn;
    @FXML
    public TableColumn<Factory, String> factoryStreetColumn;
    @FXML
    public TableColumn<Factory, String> factoryHouseNumberColumn;
    ObservableList<Factory> factoryObservableList;

    @FXML
    private void initialize() throws IOException {
        System.out.println("Init has been executed!");
        try {
            factoryObservableList = FXCollections.observableList(Database.getFactoryListFromDB());
        } catch (SQLException e) {
            e.printStackTrace();
        }
        factoryNameColumn.setCellValueFactory(cell -> {
            return new SimpleStringProperty(cell.getValue().getName());
        });
        factoryCityColumn.setCellValueFactory(cell -> {
            return new SimpleStringProperty(cell.getValue().getAddress().getGrad());
        });
        factoryPostalCodeColumn.setCellValueFactory(cell -> {
            return new SimpleStringProperty(cell.getValue().getAddress().getPostalCode());
        });
        factoryHouseNumberColumn.setCellValueFactory(cell -> {
            return new SimpleStringProperty(cell.getValue().getAddress().getHouseNumber());
        });
        factoryStreetColumn.setCellValueFactory(cell -> {
            return new SimpleStringProperty(cell.getValue().getAddress().getStreet());
        });
        factoryTableView.setItems(factoryObservableList);

    }

    public void onSearchButtonClick(){
        String tmpName = factoryNameTF.getText();
        String tmpCity = factoryCityTF.getText();
        List<Factory> filteredList = factoryObservableList.stream()
                .filter(it -> it.getName().toLowerCase().contains(tmpName.toLowerCase()))
                .filter(it -> it.getAddress().getGrad().toLowerCase().contains(tmpCity.toLowerCase()))
                .collect(Collectors.toList());
        factoryTableView.setItems(FXCollections.observableList(filteredList));
    }

}
