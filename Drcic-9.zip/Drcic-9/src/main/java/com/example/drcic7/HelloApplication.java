package com.example.drcic7;

import com.example.database.Database;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.SQLOutput;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 600, 700);
        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        try {
            System.out.println(Database.getSingleItemWithIDFromDB(Long.valueOf(7)));
            System.out.println(Database.getSingleCategoryWithIDFromDB(Long.valueOf(2)));
            System.out.println(Database.getSingleFactoryWithIDFromDB(Long.valueOf(2)));
            System.out.println(Database.getSingleStoreWithIDFromDB(Long.valueOf(2)));
            System.out.println("\n\nFactory Item Set\n");
            System.out.println(Database.getFactoryItemsFromDBAlternative(Long.valueOf(1)));
            System.out.println("\nFactory Item Set\n");
            System.out.println(Database.getFactoryItemSetFromDB(Long.valueOf(1)));
            System.out.println("\n\nStore Item Set\n");
            System.out.println(Database.getStoreItemsFromDBAlternative(Long.valueOf(1)));
            System.out.println("\nStore Item Set\n");
            System.out.println(Database.getStoreItemSetFromDB(Long.valueOf(1)));
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        launch();
    }


}