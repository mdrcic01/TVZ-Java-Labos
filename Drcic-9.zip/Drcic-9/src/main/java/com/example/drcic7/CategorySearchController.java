package com.example.drcic7;

import com.example.database.Database;
import hr.java.production.model.Category;
import hr.java.production.utilities.FileUtility;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.chart.PieChart;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.stream.Collectors;

public class CategorySearchController {
    public ObservableList<Category> categoryObservableList;

    {
        try {
            categoryObservableList = FXCollections.observableList(Database.importCategoriesFromDB());
        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public TextField categoryNameTF;
    @FXML
    public TextField categoryDescriptionTF;
    @FXML
    public TableView<Category> categoryTableView;
    @FXML
    public TableColumn<Category, String> categoryNameTableColumn;
    @FXML
    public TableColumn<Category, String> categoryDescriptionTableColumn;
    @FXML
    public TableColumn<Category, Long> categoryIDTableColumn;

    @FXML
    public void initialize(){
        categoryNameTableColumn.setCellValueFactory(cell -> {
            return new SimpleStringProperty(cell.getValue().getName());
        });
        categoryDescriptionTableColumn.setCellValueFactory(cell -> {
            return new SimpleStringProperty(cell.getValue().getDescription());
        });
        categoryIDTableColumn.setCellValueFactory(cell -> {
            return new SimpleObjectProperty<>(cell.getValue().getId());
        });
        categoryTableView.setItems(categoryObservableList);
    }

    @FXML
    public void onSearchButtonClick(){
        String tmpName = categoryNameTF.getText();
        String tmpDescription = categoryDescriptionTF.getText();
        List<Category> filteredCategoryList = categoryObservableList.stream()
                .filter(it -> it.getName().toLowerCase().contains(tmpName.toLowerCase()))
                .filter(it -> it.getDescription().toLowerCase().contains(tmpDescription.toLowerCase()))
                .collect(Collectors.toList());

        categoryTableView.setItems(FXCollections.observableList(filteredCategoryList));
    }
}
