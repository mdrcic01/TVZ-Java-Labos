package com.example.drcic7;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.MenuBar;
import javafx.stage.Stage;

import java.io.IOException;

public class MenuBarController {
    @FXML
    private MenuBar btn;
    @FXML
    protected void onItemSearchMenuClick2(ActionEvent actionEvent){
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("itemSearch.fxml"));
        Stage stage = (Stage) btn.getScene().getWindow();
        Scene scene = null;
        try{
            scene = new Scene(fxmlLoader.load(), 600, 700);
        } catch (IOException e) {
            e.printStackTrace();
        }
        stage.setScene(scene);
    }
    @FXML
    protected void onFactorySearchMenuClick(ActionEvent actionEvent){
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("factorySearch.fxml"));
        Stage stage = (Stage) btn.getScene().getWindow();
        Scene scene = null;
        try{
            scene = new Scene(fxmlLoader.load(), 600, 700);
        } catch (IOException e) {
            e.printStackTrace();
        }
        stage.setScene(scene);
    }

    @FXML
    protected void onCategorySearchMenuClick(ActionEvent actionEvent){
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("categorySearch.fxml"));
        Stage stage = (Stage) btn.getScene().getWindow();
        Scene scene = null;
        try{
            scene = new Scene(fxmlLoader.load(), 600, 700);
        } catch (IOException e) {
            e.printStackTrace();
        }
        stage.setScene(scene);
    }
    @FXML
    protected void onStoreSearchMenuClick(ActionEvent actionEvent){
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("storeSearch.fxml"));
        Stage stage = (Stage) btn.getScene().getWindow();
        Scene scene = null;
        try{
            scene = new Scene(fxmlLoader.load(), 600, 700);
        } catch (IOException e) {
            e.printStackTrace();
        }
        stage.setScene(scene);
    }
    @FXML
    protected void onAddItemMenuClick(ActionEvent actionEvent){
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("addNewItemScreen.fxml"));
        Stage stage = (Stage) btn.getScene().getWindow();
        Scene scene = null;
        try{
            scene = new Scene(fxmlLoader.load(), 600, 700);
        } catch (IOException e) {
            e.printStackTrace();
        }
        stage.setScene(scene);
    }
    @FXML
    protected void onAddCategoryMenuClick(ActionEvent actionEvent){
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("addNewCategoryScreen.fxml"));
        Stage stage = (Stage) btn.getScene().getWindow();
        Scene scene = null;
        try{
            scene = new Scene(fxmlLoader.load(), 600, 700);
        } catch (IOException e) {
            e.printStackTrace();
        }
        stage.setScene(scene);
    }
    @FXML
    protected void onAddFactoryMenuClick(ActionEvent actionEvent){
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("addNewFactoryScreen.fxml"));
        Stage stage = (Stage) btn.getScene().getWindow();
        Scene scene = null;
        try{
            scene = new Scene(fxmlLoader.load(), 600, 700);
        } catch (IOException e) {
            e.printStackTrace();
        }
        stage.setScene(scene);
    }
    @FXML
    protected void onAddStoreMenuClick(ActionEvent actionEvent){
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("addNewStoreScreen.fxml"));
        Stage stage = (Stage) btn.getScene().getWindow();
        Scene scene = null;
        try{
            scene = new Scene(fxmlLoader.load(), 600, 700);
        } catch (IOException e) {
            e.printStackTrace();
        }
        stage.setScene(scene);
    }
}
