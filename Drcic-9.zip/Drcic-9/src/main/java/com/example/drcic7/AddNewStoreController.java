package com.example.drcic7;

import com.example.database.Database;
import hr.java.production.model.Item;
import hr.java.production.model.Store;
import hr.java.production.utilities.FileUtility;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class AddNewStoreController {
    public List<Store> storeList;

    {
        try {
            storeList = Database.getStoreListFromDB();
        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }

    public ObservableList<Item> itemList;

    {
        try {
            itemList = FXCollections.observableArrayList(Database.getItemListFromDB());
        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public Label ID;
    @FXML
    public TextField nameTF;
    @FXML
    public TextField addressTF;
    @FXML
    public TableView<Item> itemTableView;
    @FXML
    public TableColumn<Item, String> itemNameTableColumn;
    @FXML
    public TableColumn<Item, BigDecimal> itemPriceTableColumn;
    @FXML
    public TableColumn<Item, BigDecimal> itemVolumeTableColumn;
    @FXML
    public TableColumn<Item, BigDecimal> itemProdCostTableColumn;

    public void initialize(){
        ID.setText(String.valueOf(storeList.size()+1));

        itemNameTableColumn.setCellValueFactory(cell -> {
            return new SimpleObjectProperty<>(cell.getValue().getName());
        });
        itemPriceTableColumn.setCellValueFactory(cell -> {
            return new SimpleObjectProperty<>(cell.getValue().getSellingPrice());
        });
        itemVolumeTableColumn.setCellValueFactory(cell -> {
            return new SimpleObjectProperty<>(cell.getValue().volumeCalc());
        });
        itemProdCostTableColumn.setCellValueFactory(cell -> {
            return new SimpleObjectProperty<>(cell.getValue().getProductionCost());
        });

        itemTableView.setItems(itemList);
        itemTableView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

    }

    public void onSaveButtonClick() throws IOException {

        StringBuilder errorMessages = new StringBuilder();


        String tmpName = nameTF.getText();
        if(tmpName.isEmpty()){
            errorMessages.append("Name is required!\n");
        }
        String tmpAddress = addressTF.getText();
        if(tmpAddress.isEmpty()){
            errorMessages.append("Address is required!\n");
        }
        Set<Item> itemSet = new HashSet<>();
        for(Item item : itemTableView.getSelectionModel().getSelectedItems()){
            itemSet.add(item);
        }
        if(itemSet.isEmpty()){
            errorMessages.append("Item list must have at least one item!\n");
        }
        if(errorMessages.isEmpty()){
            Store tmpStore = new Store(tmpName, tmpAddress, itemSet, Long.parseLong(ID.getText()));
            try {
                Database.insertStoreIntoDB(tmpStore);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                storeList = Database.getStoreListFromDB();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            ID.setText(String.valueOf(storeList.size()+1));

            nameTF.clear();
            addressTF.clear();
            itemTableView.getSelectionModel().clearSelection();

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Action successful");
            alert.setHeaderText(null);
            alert.setContentText("Your Store was saved successfully!");

            alert.showAndWait();
        }
        else{
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Action failed");
            alert.setHeaderText(null);
            alert.setContentText(errorMessages.toString());

            alert.showAndWait();
        }
    }
}
