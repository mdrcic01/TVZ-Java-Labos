package com.example.drcic7;

import com.example.database.Database;
import hr.java.production.model.Address;
import hr.java.production.model.Factory;
import hr.java.production.model.Item;
import hr.java.production.utilities.FileUtility;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class AddNewFactoryController {
    public ObservableList<Address> addressObservableList;

    {
        try {
            addressObservableList = FXCollections.observableList(Database.getAddressListFromDB());
        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }
    public ObservableList<Item> itemObservableList;

    {
        try {
            itemObservableList = FXCollections.observableArrayList(Database.getItemListFromDB());
        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }

    List<Factory> factoryList;

    {
        try {
            factoryList = Database.getFactoryListFromDB();
        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public Label ID;
    @FXML
    public TextField nameTF;
    @FXML
    public TableView<Address> addressTableView;
    @FXML
    public TableColumn<Address, String> cityTableColumn;
    @FXML
    public TableColumn<Address, String> streetTableColumn;
    @FXML
    public TableColumn<Address, String> houseNoTableColumn;
    @FXML
    public TableView<Item> itemTableView;
    @FXML
    public TableColumn<Item, String> nameTableColumn;
    @FXML
    public TableColumn<Item, BigDecimal> sellingPriceTableColumn;

    public void initialize(){
        ID.setText(String.valueOf(factoryList.size()+1));
        cityTableColumn.setCellValueFactory(cell -> {
            return new SimpleObjectProperty<>(cell.getValue().getGrad());
        });
        streetTableColumn.setCellValueFactory(cell -> {
            return new SimpleObjectProperty<>(cell.getValue().getStreet());
        });
        houseNoTableColumn.setCellValueFactory(cell -> {
            return new SimpleObjectProperty<>(cell.getValue().getHouseNumber());
        });

        addressTableView.setItems(addressObservableList);
        nameTableColumn.setCellValueFactory(cell -> {
            return new SimpleObjectProperty<>(cell.getValue().getName());
        });
        sellingPriceTableColumn.setCellValueFactory(cell -> {
            return new SimpleObjectProperty<>(cell.getValue().getSellingPrice());
        });

        itemTableView.setItems(itemObservableList);
        itemTableView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
    }

    public void onSaveButtonClick() throws IOException {

        StringBuilder errorMessages = new StringBuilder();

        Address tmpAddress = addressTableView.getSelectionModel().getSelectedItem();
        if(tmpAddress == null){
            errorMessages.append("Address is required!\n");
        }
        ObservableList<Item> tmpItemList = itemTableView.getSelectionModel().getSelectedItems();
        Set<Item> tmpItemSet = new HashSet<>();
        for (Item item : tmpItemList){
            tmpItemSet.add(item);
        }
        if (tmpItemList.isEmpty()){
            errorMessages.append("Item list must contain at least one item!\n");
        }
        String tmpName = nameTF.getText();
        if(tmpName.isEmpty()){
            errorMessages.append("Name is required!\n");
        }
        if(errorMessages.isEmpty()){
            Factory tmpFactory = new Factory(tmpName, tmpAddress, tmpItemSet);
            try {
                Database.insertFactoryIntoDB(tmpFactory);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                factoryList = Database.getFactoryListFromDB();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            ID.setText(String.valueOf(factoryList.size()+1));

            nameTF.clear();
            addressTableView.getSelectionModel().clearSelection();
            itemTableView.getSelectionModel().clearSelection();

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Action successful");
            alert.setHeaderText(null);
            alert.setContentText("Your Factory was saved successfully!");

            alert.showAndWait();
        }
        else{
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Action failed");
            alert.setHeaderText(null);
            alert.setContentText(errorMessages.toString());

            alert.showAndWait();
        }
    }
}
