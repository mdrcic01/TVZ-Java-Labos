package com.example.drcic7;

import com.example.database.Database;
import hr.java.production.model.Category;
import hr.java.production.model.Item;
import hr.java.production.utilities.FileUtility;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ItemSearch {

    ObservableList<Category> options;

    {
        try {
            options = FXCollections.observableArrayList(Database.importCategoriesFromDB());
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    ObservableList<Item> itemObservableList;

    @FXML
    private ChoiceBox<String> choiceBox;
    @FXML
    private TextField nameTextField;
    @FXML
    private TableView<Item> itemTableView;
    @FXML
    private TableColumn<Item, String> itemNameTableColumn;
    @FXML
    private TableColumn<Item, String> itemCategoryTableColumn;
    @FXML
    private TableColumn<Item, BigDecimal> itemWidthTableColumn;
    @FXML
    private TableColumn<Item, BigDecimal> itemHeightTableColumn;
    @FXML
    private TableColumn<Item, BigDecimal> itemLengthTableColumn;
    @FXML
    private TableColumn<Item, BigDecimal> itemSellingPriceTableColumn;
    @FXML
    private TableColumn<Item, BigDecimal> itemProductionCostTableColumn;

    @FXML
    protected void initialize() throws IOException {
        List<String> categoryNameList = new ArrayList<>();
        for(Category cat : options){
            categoryNameList.add(cat.getName());
        }
        ObservableList<String> catOptions = FXCollections.observableList(categoryNameList);
        catOptions.add(0, null);

        try {
            itemObservableList = FXCollections.observableArrayList(Database.getItemListFromDB());
        } catch (SQLException e) {
            e.printStackTrace();
        }


        System.out.println("Item window is now open!");
        choiceBox.setItems(catOptions);
        choiceBox.getSelectionModel().selectFirst();

        itemNameTableColumn.setCellValueFactory(cellData -> {
            return new SimpleStringProperty(cellData.getValue().getName());
        });
        itemCategoryTableColumn.setCellValueFactory(cellData -> {
            return new SimpleStringProperty(cellData.getValue().getCategory().getName());
        });
        itemWidthTableColumn.setCellValueFactory(cellData -> {
            return new SimpleObjectProperty<>(cellData.getValue().getWidth().setScale(2, RoundingMode.UP));
        });
        itemHeightTableColumn.setCellValueFactory(cellData -> {
            return new SimpleObjectProperty<>(cellData.getValue().getHeight().setScale(2, RoundingMode.UP));
        });
        itemLengthTableColumn.setCellValueFactory(cellData -> {
            return new SimpleObjectProperty<>(cellData.getValue().getLength().setScale(2, RoundingMode.UP));
        });
        itemProductionCostTableColumn.setCellValueFactory(cellData -> {
            return new SimpleObjectProperty<>(cellData.getValue().getProductionCost().setScale(2, RoundingMode.UP));
        });
        itemSellingPriceTableColumn.setCellValueFactory(cellData -> {
            return new SimpleObjectProperty<>(cellData.getValue().getSellingPrice().setScale(2, RoundingMode.UP));
        });

        itemTableView.setItems(itemObservableList);
    }
    @FXML
    protected void onSearchButtonClick(){
        String enteredText = nameTextField.getText();
        String comboBoxSelection = choiceBox.getValue();
        System.out.println(comboBoxSelection);
        List<Item> filteredList = itemObservableList.stream()
                .filter(it -> it.getName().toLowerCase().contains(enteredText.toLowerCase()))
                .collect(Collectors.toList());
        if(comboBoxSelection != null){
            filteredList = filteredList.stream().filter(it -> it.getCategory().getName().equals(comboBoxSelection))
                    .collect(Collectors.toList());
        }
        itemTableView.setItems(FXCollections.observableList(filteredList));
    }
}
