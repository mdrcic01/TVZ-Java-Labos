package com.example.drcic7;

import javafx.fxml.FXML;
import javafx.scene.image.ImageView;

;

public class HelloController {
    @FXML
    public ImageView imageView;

    @FXML
    private void initialize(){
        System.out.println("Init has been executed!");
    }

}